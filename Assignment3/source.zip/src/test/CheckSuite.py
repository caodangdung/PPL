import unittest
from TestUtils import TestChecker
from AST import *

class CheckSuite(unittest.TestCase):
 
    def test_Redeclared_Variable_a(self):
        """Simple program: int main() {} """
        input = """int a;
        int a;
        void main() {

        }
        """
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,401))   
    def test_Redeclared_FunctionAndVariable_test(self):
        """Simple program: int main() {} """
        input = """
        
        void main() {

        }
        int main;
        """
        expect = "Redeclared Variable: main"
        self.assertTrue(TestChecker.test(input,expect,402))
    def test_Redeclared_Variable_a_in_Function(self):
        """Simple program: int main() {} """
        input = """
        void main(int a) {
            boolean a;
        }
        """
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,403))
    def test_Redeclared_Variable_In_Block(self):
        """Simple program: int main() {} """
        input = """
        void main() {
            int c;
            {
                int c;
                {
                    int c;
                }
                string c;
            }
        }

        """
        expect = "Redeclared Variable: c"
        self.assertTrue(TestChecker.test(input,expect,404))
    def test_Redeclared_Variable_c(self):
        """Simple program: int main() {} """
        input = """
        int c;
        void main() {
            int c;
            {
                int c;
                {
                    int c;
                }
                float c;
            }
        }

        """
        expect = "Redeclared Variable: c"
        self.assertTrue(TestChecker.test(input,expect,405))
    def test_Redeclared_Variable(self):
        """Simple program: int main() {} """
        input = """
        int c;
        void main() {
            int c;
            boolean b;
            {
                float d;
                if (b) {
                    string d;
                    d="Hello";
                } else {
                    return;
                }
                {
                    int c;
                }
                float c;
            }
        }

        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,406))
    def test_Redeclared_Function_main(self):
        """Simple program: int main() {} """
        input = """
        int main;
        void main() {
            return;
        }
    
        """
        expect = "Redeclared Function: main"
        self.assertTrue(TestChecker.test(input,expect,407))
    def test_Redeclared_Function_foo(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 1;
        }
        float foo(){
            return 1.2;
        }
        void main() {
            foo();
        }
        
        """
        expect = "Redeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,408))
    def test_Redeclared_Parameter_name(self):
        """Simple program: int main() {} """
        input = """
        int a;
        string b;
        string foo(int name,string name){
            return name;
        }
        void main() {
            foo(a,b);
        }
        
        """
        expect = "Redeclared Parameter: name"
        self.assertTrue(TestChecker.test(input,expect,409))
    def test_Redeclared_Parameter(self):
        """Simple program: int main() {} """
        input = """
        float a;
        int foo(int a,string b){
            return a;
        }
        void main() {
            string a;
            a="dung";
            foo(1,a);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,410))
    def test_Undeclared_Identifier_b(self):
        """Simple program: int main() {} """
        input = """
        void main() {
            boolean a;
            b="string";
        }
        """
        expect = "Undeclared Identifier: b"
        self.assertTrue(TestChecker.test(input,expect,411))
    def test_Undeclared_Identifier_in_if(self):
        """Simple program: int main() {} """
        input = """
        void main() {
            boolean a;
            if (a) {
                name="string";
            } else {
                return;
            }
        }
        """
        expect = "Undeclared Identifier: name"
        self.assertTrue(TestChecker.test(input,expect,412))
    def test_Undeclared_Identifier_in_Dowwhile(self):
        """Simple program: int main() {} """
        input = """
        void main() {
            int a;
            {
                {
                    boolean b;
                    do {
                        a=2;
                        c=a+2;
                    } while(b);
                }
            }
            
        }
        """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,413))
    def test_Undeclared_Identifier_in_For(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
            int i,j;
            for(i=0;i<10;i=i+1)
            {
                for(j=i;j<10;j=j+1)
                {
                    d=a;
                }
            }
        }
        """
        expect = "Undeclared Identifier: d"
        self.assertTrue(TestChecker.test(input,expect,414))
    def test_Undeclared_Identifier_in_Call(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 0;
        }
        void main(){
            a=foo();
        }
        """
        expect = "Undeclared Identifier: a"
        self.assertTrue(TestChecker.test(input,expect,415))
    def test_Undeclared_Function_foo(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int a;
            a=foo();
        }
        """
        expect = "Undeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,416))
    def test_Undeclared_Function_foo_in_If(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int a;
            if (a==1) {
                foo();
            }
            else {
                return;
            }
        }
        """
        expect = "Undeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,417))
    def test_Undeclared_Function_foo_in_For(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int i;
            string a;
            for(i=foo();i<5;i=i+1){
                a=a+"Hello";
            }
        }
        """
        expect = "Undeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,418))
    def test_Undeclared_Function_sum_in_Return(self):
        """Simple program: int main() {} """
        input = """
        float main(){
            float a;
            return sum(a);
        }
        """
        expect = "Undeclared Function: sum"
        self.assertTrue(TestChecker.test(input,expect,419))
    def test_Undeclared_Function_test_in_complex_statements(self):
        """Simple program: int main() {} """
        input = """
        int main(){
            int a,i,j;
            a=10;
            do {
                for(i=0;i<99;i=i+1){
                    for(j=0;j<99;j=j+1)
                    {
                        if (a!=2) {
                            test();
                        } else {
                            break;
                        }
                    }
                }
                a=a-1;
            } while(a>0);
            return 0;
        }
        """
        expect = "Undeclared Function: test"
        self.assertTrue(TestChecker.test(input,expect,420))
    def test_Type_Mismatch_In_Statement_If(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            float d;
            if (d) {
                string a;
                a=a+"Test";
            } else {
                return;
            }
        }
        """
        expect = "Type Mismatch In Statement: If(Id(d),Block([VarDecl(a,StringType),BinaryOp(=,Id(a),BinaryOp(+,Id(a),StringLiteral(Test)))]),Block([Return()]))"
        self.assertTrue(TestChecker.test(input,expect,421))
    def test_Type_Mismatch_In_Statement_Return_in_If(self):
        """Simple program: int main() {} """
        input = """
        int main(){
            int d;
            if (d==1) {
                return 1;
            } else {
                return "H";
            }
        }
        """
        expect = "Type Mismatch In Statement: Return(StringLiteral(H))"
        self.assertTrue(TestChecker.test(input,expect,422))
    def test_Type_Mismatch_In_Statement_For(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            string test;
            int i;
            for(i=test;i<9;i=i+1){
                break;
            }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(i),Id(test))"
        self.assertTrue(TestChecker.test(input,expect,423))
    def test_Type_Mismatch_In_Statement_For1(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
            int i,j;
            for(i=1;i<9999999999999999;i=i+1)
            {
                for(j=1.2;j<=10;j=j+1)
                {
                    a=a*2;
                }
            }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(j),FloatLiteral(1.2))"
        self.assertTrue(TestChecker.test(input,expect,424))
    def test_Type_Mismatch_In_Statement_Dowhile(self):
        """Simple program: int main() {} """
        input = """
        boolean main(){
            int a;
            boolean check;
            check=true;
            do {
                n=n/3;
            } while(a);
            return check;
        }
        """
        expect = "Type Mismatch In Statement: Dowhile([Block([BinaryOp(=,Id(n),BinaryOp(/,Id(n),IntLiteral(3)))])],Id(a))"
        self.assertTrue(TestChecker.test(input,expect,425))
    def test_Type_Mismatch_In_Statement_Dowhile1(self):
        """Simple program: int main() {} """
        input = """
        boolean a;
        int n;
        void check(){
            do {
                do {

                } while(n);
            } while(a);
        }
        void main(){
            check();
        }
        """
        expect = "Type Mismatch In Statement: Dowhile([Block([])],Id(n))"
        self.assertTrue(TestChecker.test(input,expect,426))
    def test_Undeclared_Identifier_n(self):
        """Simple program: int main() {} """
        input = """
        boolean a;
        void check(){
            do {
                do {

                } while(n);
            } while(a);
        }
        void main(){
            check();
        }
        """
        expect = "Undeclared Identifier: n"
        self.assertTrue(TestChecker.test(input,expect,427))
    def test_Type_Mismatch_In_Statement_Return(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            float d;
            if (d) {
                string a;
                a="tl";
                return a;
            } else {
                return;
            }
        }
        """
        expect = "Type Mismatch In Statement: If(Id(d),Block([VarDecl(a,StringType),BinaryOp(=,Id(a),StringLiteral(tl)),Return(Id(a))]),Block([Return()]))"
        self.assertTrue(TestChecker.test(input,expect,428))
    def test_Type_Mismatch_In_Statement_exp2For(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
           for(a=1;a=a*10;a=a+1){
               break;
           }
        }
        """
        expect = "Type Mismatch In Statement: For(BinaryOp(=,Id(a),IntLiteral(1));BinaryOp(=,Id(a),BinaryOp(*,Id(a),IntLiteral(10)));BinaryOp(=,Id(a),BinaryOp(+,Id(a),IntLiteral(1)));Block([Break()]))"
        self.assertTrue(TestChecker.test(input,expect,429))
    def test_Type_Mismatch_In_Statement_Return_Float_String(self):
        """Simple program: int main() {} """
        input = """
        string a;
        float main(){
            a="Hello";
            return a;
        }
        """
        expect = "Type Mismatch In Statement: Return(Id(a))"
        self.assertTrue(TestChecker.test(input,expect,430))
    def test_Type_Mismatch_In_Statement_ArrayType(self):
        """Simple program: int main() {} """
        input = """
        int d[3];
        float[] foo(){
            return d;
        }
        void main(){
            foo();
        }
        """
        expect = "Type Mismatch In Statement: Return(Id(d))"
        self.assertTrue(TestChecker.test(input,expect,431))
    def test_Type_Mismatch_In_Statement_Return_float_int(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 1.2;
        }
        void main(){
            foo();
        }
        """
        expect = "Type Mismatch In Statement: Return(FloatLiteral(1.2))"
        self.assertTrue(TestChecker.test(input,expect,432))
    def test_Type_Mismatch_In_Statement_Return_coerce_int(self):
        """Simple program: int main() {} """
        input = """
        int a;
        float foo(){
            return a;
        }
        void main(){
            foo();
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,433))
    def test_Type_Mismatch_In_Statement_return_true(self):
        """Simple program: int main() {} """
        input = """
        int d;
        int foo(int a){
            return d;
        }
        void main(){
            float a;
            a=foo(d);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,434))
    def test_Type_Mismatch_In_Statement_Return_complex(self):
        """Simple program: int main() {} """
        input = """
        float d[3];
        float[] foo(){
            return d;
        }
        void main(){
            boolean a;
            for(1;1<2;1){
                if (a) {
                    a=false;
                } else {
                    return 0;
                }
            }
            foo();
        }
        """
        expect = "Type Mismatch In Statement: Return(IntLiteral(0))"
        self.assertTrue(TestChecker.test(input,expect,435))
    def test_Type_Mismatch_In_Statement_ArrayType1(self):
        """Simple program: int main() {} """
        input = """
        int d[3];
        float[] foo(){
            return d;
        }
        void main(){
            boolean a;
            for(1;1<2;1){
                if (a) {
                    a=false;
                } else {
                    return 0;
                }
            }
            foo();
        }
        """
        expect = "Type Mismatch In Statement: Return(Id(d))"
        self.assertTrue(TestChecker.test(input,expect,436))
    def test_Type_Mismatch_In_Statement_Return_boolean(self):
        """Simple program: int main() {} """
        input = """
        boolean a;
        int foo(int b){
            return a;
        }
        void main(){
            int a;
            a=foo(b);
        }
        """
        expect = "Type Mismatch In Statement: Return(Id(a))"
        self.assertTrue(TestChecker.test(input,expect,437))
    def test_Type_Mismatch_In_Expression_ArrayType(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
            a=a[1];
        }
        """
        expect = "Type Mismatch In Expression: ArrayCell(Id(a),IntLiteral(1))"
        self.assertTrue(TestChecker.test(input,expect,438))
    def test_Type_Mismatch_In_Expression_ArrayType_float(self):
        """Simple program: int main() {} """
        input = """
        int d[3];
        int[] foo(){
            return d;
        }
        void main(){
            int a;
            a=d[1.5];
            foo();
        }
        """
        expect = "Type Mismatch In Expression: ArrayCell(Id(d),FloatLiteral(1.5))"
        self.assertTrue(TestChecker.test(input,expect,439))
    def test_Type_Mismatch_In_Expression_ArrayType_boolean(self):
        """Simple program: int main() {} """
        input = """
        int d[3];
        int[] foo(){
            return d;
        }
        void main(){
            int a;
            a=d[true];
            foo();
        }
        """
        expect = "Type Mismatch In Expression: ArrayCell(Id(d),BooleanLiteral(true))"
        self.assertTrue(TestChecker.test(input,expect,440))
    def test_Type_Mismatch_In_Statement_ArrayType_string(self):
        """Simple program: int main() {} """
        input = """
        int d[3];
        int[] foo(){
            return d;
        }
        void main(){
            int a;
            a=d["string"];
            foo();
        }
        """
        expect = "Type Mismatch In Expression: ArrayCell(Id(d),StringLiteral(string))"
        self.assertTrue(TestChecker.test(input,expect,441))
    def test_Type_Mismatch_In_Expression_BinaryOp_add(self):
        """Simple program: int main() {} """
        input = """
        boolean a;
        void main(){
            int b;
            b=1+a;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(+,IntLiteral(1),Id(a))"
        self.assertTrue(TestChecker.test(input,expect,442))
    def test_Type_Mismatch_In_Expression_BinaryOp_add1(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int b;
            b=1+"string";
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(+,IntLiteral(1),StringLiteral(string))"
        self.assertTrue(TestChecker.test(input,expect,443))
    def test_Type_Mismatch_In_Expression_BinaryOp_add_int(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int b;
            b=1.5+99+99+99+1+1;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),BinaryOp(+,BinaryOp(+,BinaryOp(+,BinaryOp(+,BinaryOp(+,FloatLiteral(1.5),IntLiteral(99)),IntLiteral(99)),IntLiteral(99)),IntLiteral(1)),IntLiteral(1)))"
        self.assertTrue(TestChecker.test(input,expect,444))
    def test_Type_Mismatch_In_Expression_BinaryOp_true(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            float b;
            b=1-5.1+3;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,445))
    def test_Type_Mismatch_In_Expression_BinaryOp_add_float(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int a;
            a=1-5.1+3;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(a),BinaryOp(+,BinaryOp(-,IntLiteral(1),FloatLiteral(5.1)),IntLiteral(3)))"
        self.assertTrue(TestChecker.test(input,expect,446))
    def test_Type_Mismatch_In_Expression_BinaryOp_multi_boolean(self):
        """Simple program: int main() {} """
        input = """
        float a;
        void main(){
            boolean check;
            a=a*2*check;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(*,BinaryOp(*,Id(a),IntLiteral(2)),Id(check))"
        self.assertTrue(TestChecker.test(input,expect,447))
    def test_Type_Mismatch_In_Expression_BinaryOp_add_string(self):
        """Simple program: int main() {} """
        input = """
        string test;
        void main(){
            test="test"+"string";
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(+,StringLiteral(test),StringLiteral(string))"
        self.assertTrue(TestChecker.test(input,expect,448))
    def test_Type_Mismatch_In_Expression_BinaryOp_multi_string(self):
        """Simple program: int main() {} """
        input = """
        string foo(string a){
            return a;
        }
        void main(){
            string a;
            a=foo(a)*"test";
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(*,CallExpr(Id(foo),[Id(a)]),StringLiteral(test))"
        self.assertTrue(TestChecker.test(input,expect,449))
    def test_Type_Mismatch_In_Expression_BinaryOp_div_float(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
            int b;
            b=a/9.1;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),BinaryOp(/,Id(a),FloatLiteral(9.1)))"
        self.assertTrue(TestChecker.test(input,expect,450))
    def test_Type_Mismatch_In_Expression_BinaryOp_div_int(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
            int b;
            b=a/1;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,451))
    def test_Type_Mismatch_In_Expression_BinaryOp_div_boolean(self):
        """Simple program: int main() {} """
        input = """
        int a;
        boolean check;
        void main(){
            a/check;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(/,Id(a),Id(check))"
        self.assertTrue(TestChecker.test(input,expect,452))
    def test_Type_Mismatch_In_Expression_BinaryOp_div_assign_string(self):
        """Simple program: int main() {} """
        input = """
        string a;
        void main(){
            a="dung";
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,453))
    def test_Type_Mismatch_In_Expression_BinaryOp_div_float1(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
            int b;
            b=a/9.1;
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),BinaryOp(/,Id(a),FloatLiteral(9.1)))"
        self.assertTrue(TestChecker.test(input,expect,454))
    def test_Type_Mismatch_In_Expression_BinaryOp_boolean(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            string a;
            string b;
           if (true==false){
               if (a!=b)  {

               } else {

               }
           } else {

           }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(!=,Id(a),Id(b))"
        self.assertTrue(TestChecker.test(input,expect,455))
    def test_Type_Mismatch_In_Expression_BinaryOp_boolean1(self):
        """Simple program: int main() {} """
        input = """
        string b;
        void main(){
            boolean a;
            a=true;
            b="dung";
            do {

            } while(a!=false && b=="dung");
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(==,Id(b),StringLiteral(dung))"
        self.assertTrue(TestChecker.test(input,expect,456))
    def test_Type_Mismatch_In_Expression_BinaryOp_modulus_float(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
           if (true==false){
               
           } else {
               a=a%6.1;
           }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(%,Id(a),FloatLiteral(6.1))"
        self.assertTrue(TestChecker.test(input,expect,457))
    def test_Type_Mismatch_In_Expression_BinaryOp_modulus_int(self):
        """Simple program: int main() {} """
        input = """
        int a;
        void main(){
           do {
               a=a%10;
           } while(true);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,458))
    def test_Type_Mismatch_In_Expression_BinaryOp_modulus_string(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int a;
            int b;
           if (true==false){
               if (a!=b)  {
                   a=b%"dung";
               } else {

               }
           } else {

           }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(%,Id(b),StringLiteral(dung))"
        self.assertTrue(TestChecker.test(input,expect,459))
    def test_Type_Mismatch_In_Expression_BinaryOp_modulus_boolean(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int i,a;
            for(i=0;i<=10;i=i+1){
                a=a%true;
            }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(%,Id(a),BooleanLiteral(true))"
        self.assertTrue(TestChecker.test(input,expect,460))
    def test_Type_Mismatch_In_Expression_UnaryOp_Not_int(self):
        """Simple program: int main() {} """
        input = """
        int d;
        void main(){
            d=-1;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,461))
    def test_Type_Mismatch_In_Expression_UnaryOp_Not_float(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            float a;
            a=8.1;
            -a;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,462))
    def test_Type_Mismatch_In_Expression_UnaryOp_not_boolean(self):
        """Simple program: int main() {} """
        input = """
        void main(){
           do{

           } while(-true);
        }
        """
        expect = "Type Mismatch In Expression: UnaryOp(-,BooleanLiteral(true))"
        self.assertTrue(TestChecker.test(input,expect,463))
    def test_Type_Mismatch_In_Expression_UnaryOp_not_string(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            string a;
            if (-a){

            }else {

            }
        }
        """
        expect = "Type Mismatch In Expression: UnaryOp(-,Id(a))"
        self.assertTrue(TestChecker.test(input,expect,464))
    def test_Type_Mismatch_In_Expression_UnaryOp_logic_not_int(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int i;
            for(i=0;!1;i=i+1){
               
            }
        }
        """
        expect = "Type Mismatch In Expression: UnaryOp(!,IntLiteral(1))"
        self.assertTrue(TestChecker.test(input,expect,465))
    def test_Type_Mismatch_In_Expression_UnaryOp_logic_not_float(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            if (!2.1){

            }else{

            }
        }
        """
        expect = "Type Mismatch In Expression: UnaryOp(!,FloatLiteral(2.1))"
        self.assertTrue(TestChecker.test(input,expect,466))
    def test_Type_Mismatch_In_Expression_UnaryOp_logic_not_string(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            string check;
            check="a";
            do {

            } while(!check);
        }
        """
        expect = "Type Mismatch In Expression: UnaryOp(!,Id(check))"
        self.assertTrue(TestChecker.test(input,expect,467))
    def test_Type_Mismatch_In_Expression_UnaryOp_logic_not_boolean(self):
        """Simple program: int main() {} """
        input = """
        boolean test;
        void main(){
            test=true;
            int i,a;
            if (!test){
                for(i=0;i<=10;i=i+1){
                    a=a+1;
                }
            } else{

            }
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,468))
    def test_Type_Mismatch_In_Expression_UnaryOp_modulus_boolean(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int i,a;
            for(i=0;i<=10;i=i+1){
                a=a%true;
            }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(%,Id(a),BooleanLiteral(true))"
        self.assertTrue(TestChecker.test(input,expect,469))
    def test_Type_Mismatch_In_Expression_LHS_voidtype(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            boolean a;
            if (a){
                main=0;
            }else{
                return;
            }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(main),IntLiteral(0))"
        self.assertTrue(TestChecker.test(input,expect,470))
    def test_Type_Mismatch_In_Expression_LHS_arraypointertype(self):
        """Simple program: int main() {} """
        input = """
        int a[4];
        int[] foo(){
            return a;
        }
        void main(){
            boolean a;
            if (a){
                foo=0;
            }else{
                return;
            }
        }
        """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(foo),IntLiteral(0))"
        self.assertTrue(TestChecker.test(input,expect,471))
    def test_Type_Mismatch_In_Expression_funcall_not_param(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 0;
        }
        void main(){
            boolean a;
            a=true;
            if (a){
                
            }else{
                foo(a);
            }
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo),[Id(a)])"
        self.assertTrue(TestChecker.test(input,expect,472))
    def test_Type_Mismatch_In_Expression_funcall_param(self):
        """Simple program: int main() {} """
        input = """
        float foo(int a,int b){
            return 0;
        }
        void main(){
            boolean a;
            a=true;
            if (a){
                
            }else{
                foo(a,a);
            }
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo),[Id(a),Id(a)])"
        self.assertTrue(TestChecker.test(input,expect,473))
    def test_Type_Mismatch_In_Expression_funcall_param_int(self):
        """Simple program: int main() {} """
        input = """
        float d[4];
        float[] test(int a,int b){
            return d;
        }
        void main(){
            boolean a;
            a=true;
            int d;
            d=10;
            do{
                test(d,test(d,d));
            } while(a);
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(test),[Id(d),CallExpr(Id(test),[Id(d),Id(d)])])"
        self.assertTrue(TestChecker.test(input,expect,474))
    def test_Type_Mismatch_In_Expression_funcall_param_array(self):
        """Simple program: int main() {} """
        input = """
         float d[4];
        float[] test(float a[],float b[]){
            return d;
        }
        void main(){
            boolean a;
            a=true;
            int d[4];
            do{
                test(d,test(d,d));
            } while(a);
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(test),[Id(d),Id(d)])"
        self.assertTrue(TestChecker.test(input,expect,475))
    def test_Type_Mismatch_In_Expression_funcall_param_float_int(self):
        """Simple program: int main() {} """
        input = """
        string d[4];
        string[] test(float a[],int b[]){
            return d;
        }
        void main(){
            boolean a;
            a=true;
            int d[4];
            do{
                test(d,test(d,d));
            } while(a);
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(test),[Id(d),Id(d)])"
        self.assertTrue(TestChecker.test(input,expect,476))
    def test_Type_Mismatch_In_Expression_funcall_param_float_int1(self):
        """Simple program: int main() {} """
        input = """
        string d[4];
        string[] test(float a[],int b[]){
            return d;
        }
        void main(){
            boolean a;
            a=true;
            float d[4];
            if (a){
                test(d,test(d,d));
            } else{
                return;
            }
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(test),[Id(d),Id(d)])"
        self.assertTrue(TestChecker.test(input,expect,477))
    def test_Type_Mismatch_In_Expression_funcall_float(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 1;
        }
        void main(){
            boolean a;
            foo();
            a=check(1.2);
        }
        boolean check(int a){
            if (true) {
                check(a);
            }
            return true;
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(check),[FloatLiteral(1.2)])"
        self.assertTrue(TestChecker.test(input,expect,478))
    def test_Type_Mismatch_In_Expression_funcall_param_string(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 1;
        }
        void main(){
            string b;
            boolean a;
            foo();
            a=check(b);
        }
        boolean check(string a){
            if (true) {
                check(a);
            }
            return true;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,479))
    def test_Type_Mismatch_In_Expression_funcall_in_funcall(self):
        """Simple program: int main() {} """
        input = """
        int foo(int a){
           return check(a);
        }
        void main(){
            int a;
            a=foo();
        }
        int check(float a){
            if (true) {
                return 0;
            }
            return 1;
        }
        """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo),[])"
        self.assertTrue(TestChecker.test(input,expect,480))
    def test_function_not_return_in_if(self):
        """Simple program: int main() {} """
        input = """
        int foo(int a){
           return check(a);
        }
        void main(){
            int a;
            a=foo(a);
        }
        int check(float a){
            if (true) {
                return 0;
            }
        }
        """
        expect = "Function check Not Return "
        self.assertTrue(TestChecker.test(input,expect,481))
    def test_function_not_return_in_for(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            float a;
            a=test(a);
        }
        float test(float a){
            for(1;true;1){
                return 1;
            }
        }
        """
        expect = "Function test Not Return "
        self.assertTrue(TestChecker.test(input,expect,482))
    def test_function_not_return_in_dowhile(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            test();
        }
        string test(){
            do{
                return "dung";
            } while(true);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,483))
    def test_function_not_return_if_not_else(self):
        """Simple program: int main() {} """
        input = """
        
        void main(){
            sum(1,2);
        }
        float sum(int a,int b){
            if (true) {
                return a+b;
            } else{

            }
        }
        """
        expect = "Function sum Not Return "
        self.assertTrue(TestChecker.test(input,expect,484))
    def test_function_not_return_not_if_else(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            sum(1,2);
        }
        float sum(int a,int b){
            if (true) {
                
            } else{
                return a+b;
            }
        }
        """
        expect = "Function sum Not Return "
        self.assertTrue(TestChecker.test(input,expect,485))
    def test_function_not_return_if_else(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            sum(1,2);
        }
        float sum(int a,int b){
            if (true) {
                return a;
            } else{
                return a+b;
            }
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,486))
    def test_function_not_return_if_for(self):
        """Simple program: int main() {} """
        input = """
        float cacul(int a,int b){
            if (true) {
                for(1;true;1){
                    return a;
                }
            } else{
                return a+b;
            }
        }
        void main(){
            cacul(1,2);
        }
        """
        expect = "Function cacul Not Return "
        self.assertTrue(TestChecker.test(input,expect,487))
    def test_function_not_return_if_dowhile(self):
        """Simple program: int main() {} """
        input = """
        float cacul(int a,int b){
            if (true) {
                return b;
            } else{
                do {
                    return a;
                } while(true);
            }
        }
        void main(){
            cacul(1,2);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,488))
    def test_break_not_in_loop_func_main(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            break;
        }
        """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,489))
    def test_continue_not_in_loop_in_func(self):
        """Simple program: int main() {} """
        input = """
        float check(int a,int b){
           continue;
           return a;
        }
        void main(){
            check(1,1);
        }
        """
        expect = "Continue Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,490))
    def test_break_not_in_loop_in_if(self):
        """Simple program: int main() {} """
        input = """
        float check(int a,int b){
            if (true) {
                
            } else{
                break;
            }
            return a+b;
        }
        void main(){
            check(1,1);
        }
        """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,491))
    def test_continue_not_in_loop_in_dowhile(self):
        """Simple program: int main() {} """
        input = """
        float cacul(int a,int b){
            do {
                a=a+1;
                continue;
            } while(true);
            return 1;
        }
        void main(){
            cacul(1,2);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,492))
    def test_break_not_in_loop_for(self):
        """Simple program: int main() {} """
        input = """
         float cacul(int a,int b){
            if (true) {
                for(1;true;1){
                    break;
                }
            } else{
                
            }
            return a+b;
        }
        void main(){
            cacul(1,2);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,493))
    def test_No_Entry_Point(self):
        """Simple program: int main() {} """
        input = """
         float cacul(int a,int b){
            do {
                a=a+1;
                continue;
            } while(true);
            return 1;
        }
        void foo(){
            cacul(1,2);
        }
        """
        expect = "No Entry Point"
        self.assertTrue(TestChecker.test(input,expect,494))
    def test_Unreachable_Function_foo(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 1;
        }
        void main(){
            
        }
        """
        expect = "Unreachable Function: foo"
        self.assertTrue(TestChecker.test(input,expect,495))
    def test_Unreachable_Function_test(self):
        """Simple program: int main() {} """
        input = """
        int foo(int a){
            return a;
        }
        void main(){
            
        }
        float test(){
            return foo(1);
        }
        """
        expect = "Unreachable Function: test"
        self.assertTrue(TestChecker.test(input,expect,496))
    def test_Unreachable_Function_check(self):
        """Simple program: int main() {} """
        input = """
        boolean check(){
            return true;
        }
        void main(){
            boolean a;
            if (true){
                {
                    {
                        {
                            {
                                a=check();
                            }
                        }
                    }
                }
            }else{

            }
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,497))
    def test_Not_Left_Value_in_funcall(self):
        """Simple program: int main() {} """
        input = """
        int foo(){
            return 1;
        }
        void main(){
            foo()=1;
        }
        """
        expect = "Not Left Value: CallExpr(Id(foo),[])"
        self.assertTrue(TestChecker.test(input,expect,498))
    def test_Not_Left_Value_func_arraypointertype(self):
        """Simple program: int main() {} """
        input = """
        string[] test(string a[]){
            return a;
        }
        void main(){
            string a[1];
            do{
                {
                    {
                        {
                            {
                                {
                                    {
                                        if (true){
                                            {
                                                test(a)=1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }while(true);
        }
        """
        expect = "Not Left Value: CallExpr(Id(test),[Id(a)])"
        self.assertTrue(TestChecker.test(input,expect,499))
    def test_Not_Left_Value(self):
        """Simple program: int main() {} """
        input = """
        void main(){
            int a;
            a+3=1;
        }
        """
        expect = "Not Left Value: BinaryOp(+,Id(a),IntLiteral(3))"
        self.assertTrue(TestChecker.test(input,expect,500))