
"""
 * @author nhphung
"""
#-------------------MSSV:1710849---------------------

from AST import * 
from Visitor import *
from Utils import Utils
from StaticError import *
from functools import *

class MType:
    def __init__(self,partype,rettype):
        self.partype = partype
        self.rettype = rettype

class Symbol:
    def __init__(self,name,mtype,value = None):
        self.name = name
        self.mtype = mtype
        self.value = value
class StaticChecker(BaseVisitor,Utils):

    global_envi = [
        Symbol("getInt", MType([], IntType())),
        Symbol("putInt", MType([IntType()], VoidType())),
        Symbol("putIntLn", MType([IntType()], VoidType())),
        Symbol("getFloat", MType([], FloatType())),
        Symbol("putFloat", MType([FloatType()], VoidType())),
        Symbol("putFloatLn", MType([FloatType()], VoidType())),
        Symbol("putBool", MType([BoolType()], VoidType())),
        Symbol("putBoolLn", MType([BoolType()], VoidType())),
        Symbol("putString", MType([StringType()], VoidType())),
        Symbol("putStringLn", MType([StringType()], VoidType())),
        Symbol("putLn", MType([], VoidType()))
    ]
            
    
    def __init__(self,ast):
        self.ast = ast

    def check(self):
        return self.visit(self.ast,StaticChecker.global_envi)
        
    def checkRedeclared(self,sym,kind,c):
        if self.lookup(sym.name,c,lambda x:x.name):
                raise Redeclared(kind,sym.name)
        else:
            return sym

    def visitProgram(self,ast,c):
        isMain=False
        Unreachable=[]
        for x in ast.decl:
            if isinstance(x,FuncDecl):
                if x.name.name=="main":
                    isMain=True
                else:
                    Unreachable.append(x.name.name)
        if isMain is False:
            raise NoEntryPoint()
        
        global_ref=c[:]
        for x in ast.decl:
            if not isinstance(x,FuncDecl):
                global_ref+=[self.visit(x,global_ref)]
            else:
                kind=Function()
                global_ref+=[self.checkRedeclared(Symbol(x.name.name,MType([i.varType for i in x.param],x.returnType)),kind,global_ref)]
        
        func_ref=filter(lambda x:isinstance(x,FuncDecl),ast.decl)
        
        for x in func_ref:
            nameFunc=x.name.name
            self.visit(x,(global_ref,Unreachable,nameFunc))
        if len(Unreachable)!=0:
            raise UnreachableFunction(Unreachable[0])
        return global_ref

    def visitFuncDecl(self,ast,c):
        paramList = []
        for x in ast.param:
            try:
                paramList += [self.visit(x, paramList)]
            except Redeclared as e:
                raise Redeclared(Parameter(), e.n)

        isReturn=False
        if isinstance(ast.returnType,VoidType):
            isReturn=True
        for x in ast.body.member:
            if isinstance(x,VarDecl):
                paramList+=[self.visit(x,paramList)]
            else:
                if self.visit(x,(paramList+c[0],False,ast.returnType,c[1],c[2])) is True:
                    isReturn=True
            
        if isReturn is False:
            raise FunctionNotReturn(ast.name.name)
        return paramList
    def visitBlock(self,ast,c):
        blockList=[]
        
        isReturn=False
        for x in ast.member:
            if isinstance(x,VarDecl):
                blockList+=[self.visit(x,blockList)]
            else:
                if self.visit(x,(blockList+c[0],c[1],c[2],c[3],c[4])) is True:
                    isReturn=True
        return isReturn
    def visitVarDecl(self,ast,c):
        if not isinstance(ast.variable,str):
            self.visit(ast.variable,c)
        kind=Variable()
        return self.checkRedeclared(Symbol(ast.variable, ast.varType),kind,c)

    def visitIntLiteral(self,ast, c):
        return IntType()

    def visitFloatLiteral(self, ast, c):
        return FloatType()

    def visitStringLiteral(self, ast, c):
        return StringType()

    def visitBooleanLiteral(self, ast, c):
        return BoolType()

    def visitBinaryOp(self, ast, c):
        left = self.visit(ast.left, c)
        right = self.visit(ast.right, c)
        op = ast.op
        def CheckType(acceptType, returnType = None):
            if not isinstance(left, acceptType) or not isinstance(right, acceptType):
                raise TypeMismatchInExpression(ast)
            if returnType:
                return returnType
            if isinstance(left, FloatType) and isinstance(right, (IntType, FloatType)):
                return FloatType()
            if isinstance(left, BoolType) and isinstance(right, BoolType):
                return BoolType()
            if isinstance(left, IntType) and isinstance(right, FloatType):
                return FloatType()
            if isinstance(left, type(right)):
                return left
            else:
                raise TypeMismatchInExpression(ast)
        if op in ['=']:
            if not type(ast.left) in [Id,ArrayCell]:
                raise NotLeftValue(ast.left)
            elif isinstance(left,IntType) and isinstance(right,FloatType):
                raise TypeMismatchInExpression(ast)
            else:
                return CheckType((FloatType, IntType, BoolType, StringType))
        if op in ['+', '-', '*','/']:
            return CheckType((FloatType, IntType))
        if op in ['%']:
            return CheckType((IntType))
        if op in ['==','!=']:
            if isinstance(left,BoolType) and isinstance(right,BoolType):
                return BoolType()
            return CheckType((IntType),BoolType())
        if op in ['&&', '||']:
            return CheckType((BoolType), BoolType())
        if op in ['<', '<=', '>=', '>']:
            return CheckType((IntType, FloatType), BoolType())
    def visitId(self, ast, c):

        kind = Identifier() if len(c)==3 else c[1]
        env = c if not isinstance(c, tuple) else c[0]
        if isinstance(env,tuple):
            res = self.lookup(ast.name, env[0], lambda x: x.name)
        else:
            res = self.lookup(ast.name, env, lambda x: x.name)
        if res is None:
            if kind in [False,True]:
                raise Undeclared(Identifier(), ast.name)
            raise Undeclared(kind, ast.name)
        return res.mtype
    def visitUnaryOp(self, ast, c):
        op = ast.op
        exp = self.visit(ast.body, c)

        if op in ['!']:
            if not isinstance(exp, BoolType):
                raise TypeMismatchInExpression(ast)
            else:
                return BoolType()

        if op in ['-']:
            if not isinstance(exp, (IntType, FloatType)):
                raise TypeMismatchInExpression(ast)
            else:
                return exp
    def visitReturn(self, ast, c):
        if ast.expr is None:
            if not isinstance(c[2],VoidType):
                raise TypeMismatchInStatement(ast)
        elif isinstance(c[2], VoidType):
            raise TypeMismatchInStatement(ast)
        else:
            res = self.visit(ast.expr, c)
            if isinstance(c[2], FloatType):
                if not isinstance(res, (FloatType, IntType)):
                    raise TypeMismatchInStatement(ast)
            elif isinstance(c[2], ArrayPointerType):
                if  not type(res) in [ArrayType,ArrayPointerType]:
                    raise TypeMismatchInStatement(ast)
                else:
                    validType=[(StringType,StringType),(BoolType,BoolType),(IntType,IntType),(FloatType,FloatType)]
                
                    if not (type(c[2].eleType),type(res.eleType)) in validType:
                         raise TypeMismatchInStatement(ast)
            elif not isinstance(res, type(c[2])):
                raise TypeMismatchInStatement(ast)
        
        return True
    def visitCallExpr(self,ast,c):
        
        Unreachable=c[3]
        nameFunc=c[4]
        if ast.method.name != nameFunc:
            if ast.method.name in Unreachable:
                Unreachable.remove(ast.method.name)

        at = [self.visit(x,c) for x in ast.param]
        if isinstance(ast, CallExpr):
            kind=Function()
        res = self.visit(ast.method, (c,kind))
        if res is None:
            raise Undeclared(kind, ast.method.name)
        elif not isinstance(res, MType):
                raise TypeMismatchInExpression(ast)
        if len(res.partype) != len(at):
                raise TypeMismatchInExpression(ast)
       
        for x in zip(res.partype, at):
            left = x[0]
            right = x[1]
            self.checkType(left, right, ast, kind)
       
        return res.rettype
    def checkType(self, left, right, ast, kind):
       
        if type(left) in [ArrayType,ArrayPointerType]:
            if not type(right) in [ArrayType,ArrayPointerType]:
                raise TypeMismatchInExpression(ast)
            if not isinstance(left.eleType, type(right.eleType)):
                raise TypeMismatchInExpression(ast)
        elif isinstance(left, FloatType):
            if not isinstance(right, (FloatType, IntType)):
                raise TypeMismatchInExpression(ast)
        elif not isinstance(left, type(right)):
            raise TypeMismatchInExpression(ast)
    def visitIf(self, ast, c):
        exp_type = self.visit(ast.expr, c)
        if not isinstance(exp_type, BoolType):
            raise TypeMismatchInStatement(ast)
        isReturnThen=self.visit(ast.thenStmt,c)
        if not ast.elseStmt is None:
            isReturnElse=self.visit(ast.elseStmt,c)
            if  (isReturnElse and isReturnThen) is True:
                return True
            else:
                return False 
        else:
            return False
    def visitDowhile(self, ast, c):
        exp_type = self.visit(ast.exp, c)
        if not isinstance(exp_type, BoolType):
            raise TypeMismatchInStatement(ast)

        isReturn = False
        for stmt in ast.sl:
            if self.visit(stmt, (c[0], True, c[2],c[3],c[4])) is True:
                isReturn=True
               
        return isReturn
    def visitFor(self, ast, c):
      
        expr1_type = self.visit(ast.expr1, c)
        expr2_type = self.visit(ast.expr2, c)
        expr3_type = self.visit(ast.expr3, c)

        if not isinstance(expr1_type, IntType) or not isinstance(expr2_type, BoolType) or not isinstance(expr3_type, IntType):
            raise TypeMismatchInStatement(ast)
        self.visit(ast.loop, (c[0], True, c[2],c[3],c[4]))
       
    def visitBreak(self, ast, c):
        if c[1] is False:
            raise BreakNotInLoop(ast)
       
    def visitContinue(self, ast, c):
        if c[1] is False:
            raise ContinueNotInLoop(ast)
        
    def visitArrayCell(self,ast,c):
        arr = self.visit(ast.arr, c)
        idx = self.visit(ast.idx, c)

        if not isinstance(arr, (ArrayType,ArrayPointerType)):
            raise TypeMismatchInExpression(ast)
        if not isinstance(idx, IntType):
            raise TypeMismatchInExpression(ast)

        return arr.eleType

    

    
    




        


    

