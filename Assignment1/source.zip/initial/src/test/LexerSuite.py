import unittest
from TestUtils import TestLexer
class LexerSuite(unittest.TestCase):
    def test_id(self):
        self.assertTrue(TestLexer.checkLexeme("abcdfgh","abcdfgh,<EOF>",101))
    def test_id1(self):
        self.assertTrue(TestLexer.checkLexeme("MNPQO","MNPQO,<EOF>",102))
    def test_id2(self):
        self.assertTrue(TestLexer.checkLexeme("aBCefGH","aBCefGH,<EOF>",103))
    def test_id3(self):
        self.assertTrue(TestLexer.checkLexeme("ABCdEfh","ABCdEfh,<EOF>",104))
    def test_id4(self):
        self.assertTrue(TestLexer.checkLexeme("_abc_abc","_abc_abc,<EOF>",105))
    def test_id5(self):
        self.assertTrue(TestLexer.checkLexeme("1234abca234","1234,abca234,<EOF>",106))
    def test_id6(self):
        self.assertTrue(TestLexer.checkLexeme("ABCbcaABC","ABCbcaABC,<EOF>",107))
    def test_id7(self):
        self.assertTrue(TestLexer.checkLexeme("@abcABC","Error Token @",108))
    def test_id8(self):
        self.assertTrue(TestLexer.checkLexeme("abc#","abc,Error Token #",109))
    def test_id9(self):
        self.assertTrue(TestLexer.checkLexeme("abc_DEF","abc_DEF,<EOF>",110))
    def test_id10(self):
        self.assertTrue(TestLexer.checkLexeme("zxuov*#^@%!","zxuov,*,Error Token #",111))

    def test_keywords(self):
        self.assertTrue(TestLexer.checkLexeme("booleanReTurn","booleanReTurn,<EOF>",112))
    def test_keywords1(self):
        self.assertTrue(TestLexer.checkLexeme("BREAKint","BREAKint,<EOF>",113))
    def test_keywords2(self):
        self.assertTrue(TestLexer.checkLexeme("Elsefloat","Elsefloat,<EOF>",114))
    def test_keywords3(self):
        self.assertTrue(TestLexer.checkLexeme("do abcs","do,abcs,<EOF>",115))
    def test_keywords4(self):
        self.assertTrue(TestLexer.checkLexeme("StRing","StRing,<EOF>",116))
    def test_keywords5(self):
        self.assertTrue(TestLexer.checkLexeme("while ABC$","while,ABC,Error Token $",117))
    def test_keywords6(self):
        self.assertTrue(TestLexer.checkLexeme("if falseINT","if,falseINT,<EOF>",118))
    def test_keywords7(self):
        self.assertTrue(TestLexer.checkLexeme("123voidABC","123,voidABC,<EOF>",119))
    def test_keywords8(self):
        self.assertTrue(TestLexer.checkLexeme("continue&234","continue,Error Token &",120))
    def test_keywords9(self):
        self.assertTrue(TestLexer.checkLexeme("12.3for456","12.3,for456,<EOF>",121))
    
    def test_operators(self):
        self.assertTrue(TestLexer.checkLexeme("++","+,+,<EOF>",122))
    def test_operators1(self):
        self.assertTrue(TestLexer.checkLexeme("--%%","-,-,%,%,<EOF>",123))
    def test_operators2(self):
        self.assertTrue(TestLexer.checkLexeme("*/+-","*,/,+,-,<EOF>",124))
    def test_operators3(self):
        self.assertTrue(TestLexer.checkLexeme("!==","!=,=,<EOF>",125))
    def test_operators4(self):
        self.assertTrue(TestLexer.checkLexeme("-!","-,!,<EOF>",126))
    def test_operators5(self):
        self.assertTrue(TestLexer.checkLexeme("|||","||,Error Token |",127))
    def test_operators6(self):
        self.assertTrue(TestLexer.checkLexeme(">==",">=,=,<EOF>",128))
    def test_operators7(self):
        self.assertTrue(TestLexer.checkLexeme("<>=","<,>=,<EOF>",129))
    def test_operators8(self):
        self.assertTrue(TestLexer.checkLexeme(">>=",">,>=,<EOF>",130))
    def test_operators9(self):
        self.assertTrue(TestLexer.checkLexeme("&&!","&&,!,<EOF>",131))

    def test_separators(self):
        self.assertTrue(TestLexer.checkLexeme("[abcDEF]","[,abcDEF,],<EOF>",132))
    def test_separators1(self):
        self.assertTrue(TestLexer.checkLexeme("{1234abc1234}","{,1234,abc1234,},<EOF>",133))
    def test_separators2(self):
        self.assertTrue(TestLexer.checkLexeme("(abc)","(,abc,),<EOF>",134))
    def test_separators3(self):
        self.assertTrue(TestLexer.checkLexeme("abcd;,","abcd,;,,,<EOF>",135))
    def test_separators4(self):
        self.assertTrue(TestLexer.checkLexeme("[({;,})]","[,(,{,;,,,},),],<EOF>",136))
    def test_separators5(self):
        self.assertTrue(TestLexer.checkLexeme("a{b)^c]","a,{,b,),Error Token ^",137))
    
    def test_integer(self):
        self.assertTrue(TestLexer.checkLexeme("1234abcd0912","1234,abcd0912,<EOF>",138))
    def test_integer1(self):
        self.assertTrue(TestLexer.checkLexeme("019128","019128,<EOF>",139))
    def test_integer2(self):
        self.assertTrue(TestLexer.checkLexeme("12345_12345","12345,_12345,<EOF>",140))
    def test_integer3(self):
        self.assertTrue(TestLexer.checkLexeme("1234$1234","1234,Error Token $",141))

    def test_float(self):
        self.assertTrue(TestLexer.checkLexeme("598.574","598.574,<EOF>",142))
    def test_float1(self):
        self.assertTrue(TestLexer.checkLexeme("23465.","23465.,<EOF>",143))
    def test_float2(self):
        self.assertTrue(TestLexer.checkLexeme(".23465",".23465,<EOF>",144))
    def test_float3(self):
        self.assertTrue(TestLexer.checkLexeme("e-12","e,-,12,<EOF>",145))
    def test_float4(self):
        self.assertTrue(TestLexer.checkLexeme("125E125","125E125,<EOF>",146))
    def test_float5(self):
        self.assertTrue(TestLexer.checkLexeme("456e-456","456e-456,<EOF>",147))
    def test_float6(self):
        self.assertTrue(TestLexer.checkLexeme("456E-456","456E-456,<EOF>",148))
    def test_float7(self):
        self.assertTrue(TestLexer.checkLexeme(".234E123",".234E123,<EOF>",149))
    def test_float8(self):
        self.assertTrue(TestLexer.checkLexeme("789.0","789.0,<EOF>",150))
    def test_float9(self):
        self.assertTrue(TestLexer.checkLexeme("345.e-345","345.e-345,<EOF>",151))
    def test_float10(self):
        self.assertTrue(TestLexer.checkLexeme("337.E234","337.E234,<EOF>",152))
    def test_float11(self):
        self.assertTrue(TestLexer.checkLexeme("12.3.4","12.3,.4,<EOF>",153))
    def test_float12(self):
        self.assertTrue(TestLexer.checkLexeme("0.9E0.5","0.9E0,.5,<EOF>",154))
    def test_float13(self):
        self.assertTrue(TestLexer.checkLexeme('.',"Error Token .",155))

    def test_comment(self):
        self.assertTrue(TestLexer.checkLexeme("/*abcdegfahd*/","<EOF>",156))
    def test_comment1(self):
        self.assertTrue(TestLexer.checkLexeme("/*abcdef*/ancb*/","ancb,*,/,<EOF>",157))
    def test_comment2(self):
        self.assertTrue(TestLexer.checkLexeme("/*abcdef\nancb\rabc*/","<EOF>",158))
    def test_comment3(self):
        self.assertTrue(TestLexer.checkLexeme("//abcdef","<EOF>",159))
    def test_comment4(self):
        self.assertTrue(TestLexer.checkLexeme("//abc\nabc\r","abc,<EOF>",160))
    def test_comment5(self):
        self.assertTrue(TestLexer.checkLexeme("//abc/*abc*/\rabc","abc,<EOF>",161))
    def test_comment6(self):
        self.assertTrue(TestLexer.checkLexeme("//abc/*abc*/\rabc","abc,<EOF>",162))
    def test_comment7(self):
        self.assertTrue(TestLexer.checkLexeme("//abc/*abc*/\rabc","abc,<EOF>",163))
    def test_comment8(self):
        self.assertTrue(TestLexer.checkLexeme("//abc/*abc*/\rabc","abc,<EOF>",164))
    def test_comment9(self):
        self.assertTrue(TestLexer.checkLexeme("///abc!@$DSAF\n","<EOF>",165))
    def test_comment10(self):
        self.assertTrue(TestLexer.checkLexeme("//123.312\ne123","e123,<EOF>",166))
    def test_comment11(self):
        self.assertTrue(TestLexer.checkLexeme("////\n//////\r","<EOF>",167))

    def test_string(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abcabc" ""","""abcabc,<EOF>""",168))
    def test_string1(self):
        self.assertTrue(TestLexer.checkLexeme(""" "123abc123" ""","""123abc123,<EOF>""",169))
    def test_string2(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\babc" ""","""abc\\babc,<EOF>""",170))
    def test_string3(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abc\nabc" ""","""Unclosed String: abc""",171))
    def test_string4(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\nabc" ""","""abc\\nabc,<EOF>""",172))
    def test_string5(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\\nabc" ""","""Illegal Escape In String: abc\\\n""",173))
    def test_string6(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\abc" ""","""Illegal Escape In String: abc\\a""",174))
    def test_string7(self):    
        self.assertTrue(TestLexer.checkLexeme(""" "abc\rabc" ""","""Unclosed String: abc""",175))
    def test_string8(self):    
        self.assertTrue(TestLexer.checkLexeme(""" "abc\nabc\r" ""","""Unclosed String: abc""",176))
    def test_string9(self):    
        self.assertTrue(TestLexer.checkLexeme(""" "\nabc\rabc\m" ""","""Unclosed String: """,177))
    def test_string10(self):
        self.assertTrue(TestLexer.checkLexeme(""" "abc"abc" ""","""abc,abc,Unclosed String:  """,178))
    def test_string11(self):    
        self.assertTrue(TestLexer.checkLexeme(""" abc\nabc" ""","""abc,abc,Unclosed String:  """,179))
    def test_string12(self):    
        self.assertTrue(TestLexer.checkLexeme(""" "\\\\abc\\\\rabc" ""","""\\\\abc\\\\rabc,<EOF>""",180)) 
    def test_string13(self):    
        self.assertTrue(TestLexer.checkLexeme("""\"\\\m""","""Unclosed String: \\\m""",181))
    def test_string14(self):    
        self.assertTrue(TestLexer.checkLexeme(""" "abc\"abc\\abc " ""","""abc,abc,Error Token \\""",182))
    def test_string15(self):    
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\\\rabc///\\//\ndef ""","""Illegal Escape In String: abc\\\\rabc///\\/""",183))  
    def test_integer5(self):   
        self.assertTrue(TestLexer.checkLexeme("5678DEF_123","5678,DEF_123,<EOF>",184))

    def test_all(self):   
        self.assertTrue(TestLexer.checkLexeme("123abc456//defgjk\n//","123,abc456,<EOF>",185))
    def test_all1(self):   
        self.assertTrue(TestLexer.checkLexeme("1.9.3.e1xyz123abc@@!abc%$#","1.9,.3,Error Token .",186))
    def test_all2(self):   
        self.assertTrue(TestLexer.checkLexeme("*&xyzquv234//caodang789","*,Error Token &",187))
    def test_all3(self):   
        self.assertTrue(TestLexer.checkLexeme("int 0.897e123.3e234","int,0.897e123,.3e234,<EOF>",188))
    def test_all4(self):   
        self.assertTrue(TestLexer.checkLexeme("boolean/*anc*///abcdef^%@&^#","boolean,<EOF>",189))
    def test_all5(self):   
        self.assertTrue(TestLexer.checkLexeme("({a||b&&c})","(,{,a,||,b,&&,c,},),<EOF>",190))
    def test_all6(self):   
        self.assertTrue(TestLexer.checkLexeme("789+-++*abc/f/nxyz","789,+,-,+,+,*,abc,/,f,/,nxyz,<EOF>",191))
    def test_all7(self):   
        self.assertTrue(TestLexer.checkLexeme("[5+6+7]-{1+2+3}abcwxto$@#!","[,5,+,6,+,7,],-,{,1,+,2,+,3,},abcwxto,Error Token $",192))
    def test_all8(self):   
        self.assertTrue(TestLexer.checkLexeme("1.2mnp(abc[xyz{123abc456}])","1.2,mnp,(,abc,[,xyz,{,123,abc456,},],),<EOF>",193))
    def test_all9(self):   
        self.assertTrue(TestLexer.checkLexeme("0.3EE0.4E0.7^","0.3,EE0,.4E0,.7,Error Token ^",194))
    def test_all10(self):   
        self.assertTrue(TestLexer.checkLexeme("[a,b,c]0110x||y","[,a,,,b,,,c,],0110,x,||,y,<EOF>",195))
    def test_all11(self):   
        self.assertTrue(TestLexer.checkLexeme(""" "123abc/*/*^%@*#^(@(#*/" ""","""123abc/*/*^%@*#^(@(#*/,<EOF>""",196))
    def test_all12(self):   
        self.assertTrue(TestLexer.checkLexeme(""" "xyztqu//\\/*\\\\\*/\\\\\n////abc" ""","""Illegal Escape In String: xyztqu//\/""",197))
    def test_all13(self):   
        self.assertTrue(TestLexer.checkLexeme(""" "1.2.e5string//3.5.ee4\\r\\r//" ""","""1.2.e5string//3.5.ee4\\r\\r//,<EOF>""",198))
    def test_all14(self):   
        self.assertTrue(TestLexer.checkLexeme(""" \\\\\\\\\\///\\123\\\//\\///abc\\//&^$#@%^&//\\//\\abc" ""","""Error Token \\""",199))
    def test_all15(self):   
        self.assertTrue(TestLexer.checkLexeme(""" float_double\\//\\//\\//////////\\\\\\\\b ""","""float_double,Error Token \\""",200))