import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):
    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,201))
    def test_wrong_miss_close(self):
        """Miss ) int main( {}"""
        input = """int a;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,202))
    def test40(self):  
        input = """int main(){
            boolean check;
            check=true;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,203))
    def test_more_complex_program(self):
        """More complex program"""
        input = """int main () {
            putIntLn(4);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,204))
    
    def test_wrong_miss_close1(self):
        """Miss ) int main( {}"""
        input = """int main( {}"""
        expect = "Error on line 1 col 10: {"
        self.assertTrue(TestParser.checkParser(input,expect,205))
    def test_simple_program_manyvar(self):
        """Miss ) int main( {}"""
        input = """int a,b,c,d[5];"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,206))
    def test_simple_program_funcdecl(self):
        """Test funcdecl_void_type"""
        input = """void main(){

        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,207))
    def test_simple_program_funcdecl_arrayPointerType(self):
        """Test funcdecl_arrayPointerType"""
        input = """int[] test(){}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,208))
    def test_complex_program_funcDecls1(self):
        """Test more funcdecl"""
        input = """string test(int test[],string test1){
            boolean check;
            check=false;
            if (check==true) a=2; else a=3;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,209))
    def test_complex_program_exp_none(self):
        """Test more funcdecl"""
        input = """string test(int test[],string test1){
            if (a<b<c) a=2; else a=3;
        }"""
        expect = "Error on line 2 col 19: <"
        self.assertTrue(TestParser.checkParser(input,expect,210))
    def test_complex_program_funcDecls2(self):
        """Test more funcdecl"""
        input = """float test(){
            int a[4],b[5],c[6],d;
            {
                a=2;
                b=3;
                c=4;
                d=a+b+c;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,211))
    def test_wrong_program_stmDoWhile(self):
        """Test more funcdecl"""
        input = """int main(){
            do while a<2;
        }"""
        expect = "Error on line 2 col 15: while"
        self.assertTrue(TestParser.checkParser(input,expect,212)) 
    def test_program_stmDoWhile(self):
        """Test more funcdecl"""
        input = """int main(){
            do {} while a<2;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,213))
    def test_program_stmBreak(self):
        """Test more funcdecl"""
        input = """boolean main(){
            break;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,214))
    def test_program_stmContinue(self):
        """Test more funcdecl"""
        input = """int main(){
            continue;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,215))
    def test_program_stmReturnNone(self):
        """Test more funcdecl"""
        input = """void main(){
            return;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,216))
    def test_program_stmReturn(self):
        """Test more funcdecl"""
        input = """boolean main(){
            return true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,217))
    def test_program_stmExp(self):
        """Test more funcdecl"""
        input = """int main(){
            !a;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,218))
    def test_program_stmIf(self):
        """Test more funcdecl"""
        input = """int main(){
            if (a<b) c=a; else c=b; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,219))
    def test_program_stmFor(self):
        """Test more funcdecl"""
        input = """int main(){
            for (i=0;i<10;i=i+1) {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,220))
    def test_program_stmBlock(self):
        """Test more funcdecl"""
        input = """int main(){
            {
                
            } 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,221))
    def test_program_stmExpAssign(self):
        """Test more funcdecl"""
        input = """int main(){
             a=b=2;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,222))
    def test_program_stmExpLogicOr(self):
        """Test more funcdecl"""
        input = """int main(){
            a || b || c; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,223))
    def test_program_stmExpLogicAnd(self):
        """Test more funcdecl"""
        input = """int main(){
           a && b && c;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,224))
    def test_program_stmExpEQ(self):
        """Test more funcdecl"""
        input = """int main(){
            a==b;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,225))
    def test_program_stmExpNotEQ(self):
        """Test more funcdecl"""
        input = """int main(){
            a!=b; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,226))
    def test_program_stmExpLessThan(self):
        """Test more funcdecl"""
        input = """int main(){
            a<b;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,227))
    def test_program_stmExpLessThanEQ(self):
        """Test more funcdecl"""
        input = """int main(){
            a<=3;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,228))
    def test_program_stmExpGreThan(self):
        """Test more funcdecl"""
        input = """int main(){
            c>2; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,229))
    def test_program_stmExpGreThanEQ(self):
        """Test more funcdecl"""
        input = """int main(){
            x>=5; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,230))
    def test_program_stmExpGreThanEQLess(self):
        """Test more funcdecl"""
        input = """int main(){
            x<=5>=4; 
        }"""
        expect = "Error on line 2 col 16: >="
        self.assertTrue(TestParser.checkParser(input,expect,231))
    def test_program_stmExpGreThanEQLess1(self):
        """Test more funcdecl"""
        input = """int main(){
            x<=5<=4; 
        }"""
        expect = "Error on line 2 col 16: <="
        self.assertTrue(TestParser.checkParser(input,expect,232))
    def test_program_stmExpAdd(self):
        """Test more funcdecl"""
        input = """int main(){
            a+b+c; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,233))
    def test_program_stmExpSub1(self):
        """Test more funcdecl"""
        input = """int main(){
            a-b-c; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,234))
    def test_program_stmExpDiv(self):
        """Test more funcdecl"""
        input = """int main(){
            a/b/c;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,235))
    def test_program_stmExpMulti(self):
        """Test more funcdecl"""
        input = """int main(){
            a*b*c; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,236))
    def test_program_stmExpModulus(self):
        """Test more funcdecl"""
        input = """int main(){
            a%b%c; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,237))
    def test_program_stmExpSub2(self):
        """Test more funcdecl"""
        input = """int main(){
            -a; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,238))
    def test_program_stmExpLogicNot(self):
        """Test more funcdecl"""
        input = """int main(){
            !b;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,239))
    def test_program_stmExpLSP_RSP(self):
        """Test more funcdecl"""
        input = """int main(){
            c+a+b; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,240))
    def test_program_stmExpLB_RP(self):
        """Test more funcdecl"""
        input = """int main(){
            a+(c+d); 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,241))
    def test_program_OperandsLiterals(self):
        """Test more funcdecl"""
        input = """int main(){
           a=2+3+4;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,242))
    def test_program_OperandsID(self):
        """Test more funcdecl"""
        input = """int main(){
            a=a+b+c+d;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,243))
    def test_program_OperandsElementArray(self):
        """Test more funcdecl"""
        input = """int main(){
           foo(2)[x+3];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,244))
    def test_program_OperandsFuncCall(self):
        """Test more funcdecl"""
        input = """int main(){
            2+foo(a+b,c+d); 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,245))
    def test_complex_program_stmExp1(self):
        """Test more funcdecl"""
        input = """int main(){
            a = b || c && d;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,246))
    def test_complex_program_stmExp2(self):
        """Test more funcdecl"""
        input = """int main(){
            2+3*4-8/2;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,247))
    def test_complex_program_stmExp3(self):
        """Test more funcdecl"""
        input = """int main(){
            foo(2)[x+3]+2*5-6/3;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,248))
    def test_complex_program_stmExp4(self):
        """Test more funcdecl"""
        input = """int main(){
             b || c && d + foo(2)[x+3];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,249))
    def test_complex_program_stmExp5(self):
        """Test more funcdecl"""
        input = """int main(){
            (2 - 1) && d + foo(2)[x+3];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,250))
    def test_complex_program_stmExp6(self):
        """Test more funcdecl"""
        input = """void main(){
           a=sub()[(1)];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,251))
    def test_complex_program_varFunc(self):
        """Test more funcdecl"""
        input = """int a,b,c,d,e,f[100];
        boolean check;
        void main(){
            if (check==false) a=a+b+c+d[5]; else a=a-b-c-d[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,252))
    def test_complex_program_x(self):
        """Test more funcdecl"""
        input = """int main(){
            int a,b,c;
            a=1;
            b=2;
            c=3;
            if (a<b<c) print(); else {}
        }"""
        expect = "Error on line 6 col 19: <"
        self.assertTrue(TestParser.checkParser(input,expect,253))
    def test_complex_program_assocleft(self):
        """Test more funcdecl"""
        input = """void main(){
            int a,b,c;
            a=1;
            b=2;
            c=3;
            if (a<(b<c)) print(); else {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,254))
    def test_complex_program_stmExp7(self):
        """Test more funcdecl"""
        input = """void main(){
            int a,b,c;
            a=1;
            b=2;
            c=3;
            do {
                a!=b;
            } while a<2;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,255))
    def test_complex_program_1(self):
        """Test more funcdecl"""
        input = """int main(){
            a+[b+c+d]+e-f;
        }"""
        expect = "Error on line 2 col 14: ["
        self.assertTrue(TestParser.checkParser(input,expect,256))
    def test_complex_program_2(self):
        """Test more funcdecl"""
        input = """int main(){
            int ,a;
            float a,b,c;
        }"""
        expect = "Error on line 2 col 16: ,"
        self.assertTrue(TestParser.checkParser(input,expect,257))
    def test_complex_program_3(self):
        """Test more funcdecl"""
        input = """
        
        """
        expect = "Error on line 3 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,258))
    def test_complex_program_4(self):
        """Test more funcdecl"""
        input = """int main(){
            int a,b,c,d,check;
            check=true
        }"""
        expect = "Error on line 4 col 8: }"
        self.assertTrue(TestParser.checkParser(input,expect,259))
    def test_complex_program_5(self):
        """Test more funcdecl"""
        input = """vOiD main(){}
        """
        expect = "Error on line 1 col 0: vOiD"
        self.assertTrue(TestParser.checkParser(input,expect,260))
    def test_complex_program_6(self):
        """Test more funcdecl"""
        input = """string a,b,c,d[1.2];"""
        expect = "Error on line 1 col 15: 1.2"
        self.assertTrue(TestParser.checkParser(input,expect,261))
    def test_complex_program_7(self):
        """Test more funcdecl"""
        input = """float test(,int a,float b){}"""
        expect = "Error on line 1 col 11: ,"
        self.assertTrue(TestParser.checkParser(input,expect,262))
    def test_complex_program_8(self):
        """Test more funcdecl"""
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do {
                    if (a=10) {} else break;
                } while a>1;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,263))
    def test_complex_program_9(self):
        """Test more funcdecl"""
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do {
                    if (a=10) {
                        if (a==2) {
                            for (x;y;z) {
                                for(a;b;c){
                                    for (t;u;v) {
                                        break;
                                    }
                                }
                            }
                        }
                    } else break;
                    a=a-1;
                } while a>0;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,264))
    def test_complex_program_10(self):
        """Test more funcdecl"""
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do 
                    if (a=10) {
                        if (a==2) {
                            for (x;y;z) {
                                for(a;b;c){
                                    for (t;u;v) {
                                        break;
                                    }
                                }
                            }
                        }
                    } else break;
                    a=a-1;
                 while a>0;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,265))
    def test_complex_program_11(self):
        """Test more funcdecl"""
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do 
                    
                 while a>0;
            }
        }"""
        expect = "Error on line 10 col 17: while"
        self.assertTrue(TestParser.checkParser(input,expect,266))
    def test_complex_program_12(self):  
        input = """int main(){
            do{
                string a,b;
                a="test";
                b="thu";
            }
            {

            }while(a==b);
          
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,267))
    def test_complex_program_13(self):  
        input = """void main(){
          float a,b;
          a=1.3;
          b=1.2;
          print(a+b);
          if (a>=b) {
              continue;
          } else return;
          for (i=0;i<=10;i=i+1) {
              print(i);
          }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,268))
    def test_complex_program_14(self):  
        input = """void main(){
         for i=10;i>0;i=i-1 {
             print(i);
         }
        }"""
        expect = "Error on line 2 col 13: i"
        self.assertTrue(TestParser.checkParser(input,expect,269))
    def test_complex_program_15(self):  
        input = """int a[];"""
        expect = "Error on line 1 col 6: ]"
        self.assertTrue(TestParser.checkParser(input,expect,270))
    def test_complex_program_16(self):  
        input = """int main(){
            int a,b[];
        }"""
        expect = "Error on line 2 col 20: ]"
        self.assertTrue(TestParser.checkParser(input,expect,271))
    def test_complex_program_17(self):  
        input = """void foo(float a[])
        int goo(float x[]) {
        float y [10];
        foo(x); 
        foo(y); 
        }"""
        expect = "Error on line 2 col 8: int"
        self.assertTrue(TestParser.checkParser(input,expect,272))
    def test_complex_program_18(self):  
        input = """void test(int a[10]) {}"""
        expect = "Error on line 1 col 16: 10"
        self.assertTrue(TestParser.checkParser(input,expect,273))
    def test_complex_program_19(self):  
        input = """void sub() {
            a=1;
        if (!a) return; 
        else return 2; 
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,274))
    def test_complex_program_20(self):  
        input = """void sub() {
            a=1;
        if () return; 
        else return 2; 
        }"""
        expect = "Error on line 3 col 12: )"
        self.assertTrue(TestParser.checkParser(input,expect,275))
    def test_complex_program_21(self):  
        input = """int[] check(int b[]) {
        int a[1];
        boolean c;
        c=true;
        if (!c) return a;
        else return b ;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,276))
    def test_complex_program_22(self):  
        input = """int add(int a,int b){
            return a+b;
        }
            void main(){
                a=5;
                b=6;
                print(add(a,b));
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,277))
    def test_complex_program_23(self):  
        input = """{

        }"""
        expect = "Error on line 1 col 0: {"
        self.assertTrue(TestParser.checkParser(input,expect,278))
    def test_complex_program_24(self):  
        input = """float test(){
            foo(2)[a[2+x]] = a[b[2]] +3;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,279))
    def test_complex_program_25(self):  
        input = """string add(string a,string b){
            return a+b;
        }
            void main(){
                a="thu";
                b="xem";
                print(add(a,b));
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,280))
    def test_complex_program_26(self):  
        input = """void main(){
            int array[5];
        }   
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,281))
    def test_complex_program_27(self):  
        input = """void main(){
            if (a==b[]) {}
        }   
        """
        expect = "Error on line 2 col 21: ]"
        self.assertTrue(TestParser.checkParser(input,expect,282))
    def test_complex_program_28(self):  
        input = """void main(){
           int a,b,c;
           a=b=c=1;
           float f[6];
           if (a==b) f[0]=1;
        }   
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,283))
    def test_complex_program_29(self):  
        input = """int a,,b,c,,d;   
        """
        expect = "Error on line 1 col 6: ,"
        self.assertTrue(TestParser.checkParser(input,expect,284))
    def test_complex_program_30(self):  
        input = """
        void cacul(int a,int b,int c){
            if ((a<b)<c) {
                for (i=0;i<10000000000;i=i+1){
                    for (j=0;j<10000000000;j=j+1){
                        for (k=0;k<10000000000;k=k+1) {
                            for (l=0;l<10000000000;l=l+1) {
                                for (m=0;m<10000000000;m=m+1) {
                                    for (n=0;n<10000000000;n=n+1) {
                                        if (i==9999999999) break; else {
                                            print(a+b+c);
                                            }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return ;
        }   
        void main(){
            cacul(99,99,99);
        }
        
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,285))
    def test_complex_program_31(self):  
        input = """float check(){
            if (exp) if (exp) else 
        }
        """
        expect = "Error on line 2 col 30: else"
        self.assertTrue(TestParser.checkParser(input,expect,286))
    def test_complex_program_32(self):  
        input = """float float(){
            if (exp) if (exp) {} else {} 
        }
        """
        expect = "Error on line 1 col 6: float"
        self.assertTrue(TestParser.checkParser(input,expect,287))
    def test_complex_program_33(self):  
        input = """void main(){
            b[c[d(10)]];
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,288))
    def test_complex_program_34(self):  
        input = """void main(){
           test();
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,289))
    def test_complex_program_35(self):  
        input = """void main(){
            a = 1 +5+6*(2-3 + 4 - 5 + (6*3/2-1));
            b = d(arr[3]);
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,290))
    def test_complex_program_36(self):  
        input = """void main(){
            a=2;
            c=a+b;
            foo(a,c);
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,291))
    def test_complex_program_37(self):  
        input = """void main(){
           a=1+2+a(3+4,5+6,b+c);
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,292))
    def test_complex_program_38(self):  
        input = """int main(){
        arr[foo()]==b=a;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,293))
    def test_complex_program_39(self):  
        input = """ void main()
        {
            a= "string"[3] + "name";
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,294))
    def test_complex_program_40(self):  
        input = """void main() {
            a= foo()[1][2][3][4];
        }
        """
        expect = "Error on line 2 col 23: ["
        self.assertTrue(TestParser.checkParser(input,expect,295))
    def test_complex_program_41(self):  
        input = """ void main(){
           ------1;
           a!b;
        }
        """
        expect = "Error on line 3 col 12: !"
        self.assertTrue(TestParser.checkParser(input,expect,296))
    def test_complex_program_42(self):  
        input = """int main(){
           foo(1)(2);
        }
        """
        expect = "Error on line 2 col 17: ("
        self.assertTrue(TestParser.checkParser(input,expect,297))
    def test_complex_program_43(self):  
        input = """int main (){
            a= foo()[foo()[foo(0)]];
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,298))
    def test_complex_program_44(self):  
        input = """int main(){
            string a;
            a=*;
        }
        """
        expect = "Error on line 3 col 14: *"
        self.assertTrue(TestParser.checkParser(input,expect,299))
    def test_complex_program_45(self):      
        input = """void main(){
            float x;
            x=1.2e3;
            (a+b)[12];
            
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,300))