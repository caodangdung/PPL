import unittest
from TestUtils import TestAST
from AST import *

class ASTGenSuite(unittest.TestCase):
    def testAST_1(self):
        """ """
        input = """int main() {}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 301))
    def testAST_2(self):
        """ """
        input = """int a,b,c,d,e,f;"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",IntType()),VarDecl("e",IntType()),VarDecl("f",IntType())]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 302))
    def testAST_3(self):
        """ """
        input = """int main(){
            boolean check;
            check=true;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("check",BoolType()),BinaryOp("=",Id("check"),BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 303))
    def testAST_4(self):
        """ """
        input = """int a,b,c,d[5];"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",ArrayType(5,IntType()))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 304))
    def testAST_5(self):
        """ """
        input = """void main(){

        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 305))
    def testAST_6(self):
        """ """
        input = """int main () {
            putIntLn(10);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("putIntLn"),[IntLiteral(10)])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 306))
    def testAST_7(self):
        """ """
        input = """string[] test(){}"""
        expect = str(Program([FuncDecl(Id("test"),[],ArrayPointerType(StringType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 307))
    def testAST_8(self):
        """ """
        input = """string test(int test[],string test1){
            boolean check;
            check=false;
            if (check==true) a=2; else a=3;
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("test",ArrayPointerType(IntType())),VarDecl("test1",StringType())],StringType(),Block([VarDecl("check",BoolType()),BinaryOp("=",Id("check"),BooleanLiteral(False)),If(BinaryOp("==",Id("check"),BooleanLiteral(True)),BinaryOp("=",Id("a"),IntLiteral(2)),BinaryOp("=",Id("a"),IntLiteral(3)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 308))
    def testAST_9(self):
        """ """
        input = """float test(){
            int a[4],b[5],c[6],d;
            {
                a=2;
                b=3;
                c=4;
                d=a+b+c+d+e+f+g+i+k;
            }
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],FloatType(),Block([VarDecl("a",ArrayType(4,IntType())),VarDecl("b",ArrayType(5,IntType())),VarDecl("c",ArrayType(6,IntType())),VarDecl("d",IntType()),Block([BinaryOp("=",Id("a"),IntLiteral(2)),BinaryOp("=",Id("b"),IntLiteral(3)),BinaryOp("=",Id("c"),IntLiteral(4)),BinaryOp("=",Id("d"),BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),Id("d")),Id("e")),Id("f")),Id("g")),Id("i")),Id("k")))])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 309))
    def testAST_10(self):
        """ """
        input = """int main(){
            do {} while a<2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([])],BinaryOp("<",Id("a"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 310))
    def testAST_11(self):
        """ """
        input = """boolean main(){
            break;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],BoolType(),Block([Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 311))
    def testAST_12(self):
        """ """
        input = """int main(){
            int a,b[10],c,d;
            continue;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",ArrayType(10,IntType())),VarDecl("c",IntType()),VarDecl("d",IntType()),Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 312))
    def testAST_13(self):
        """ """
        input = """boolean main(){
            return true;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],BoolType(),Block([Return(BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 313))
    def testAST_14(self):
        """ """
        input = """int main(){
            !a;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([UnaryOp("!",Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 314))
    def testAST_15(self):
        """ """
        input = """int main(){
            if (a<b) c=a; else c=b; 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(BinaryOp("<",Id("a"),Id("b")),BinaryOp("=",Id("c"),Id("a")),BinaryOp("=",Id("c"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 315))
    def testAST_16(self):
        """ """
        input = """int main(){
            for (i=0;i<10;i=i+1) {}
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 316))
    def testAST_17(self):
        """ """
        input = """int main(){
            {
                
            } 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Block([])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 317))
    def testAST_18(self):
        """ """
        input = """int main(){
             a=b=2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("=",Id("b"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 318))
    def testAST_19(self):
        """ """
        input = """int main(){
            a || b || c; 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("||",BinaryOp("||",Id("a"),Id("b")),Id("c"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 319))
    def testAST_20(self):
        """ """
        input = """int main(){
           a && b && c;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("&&",BinaryOp("&&",Id("a"),Id("b")),Id("c"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 320))
    def testAST_21(self):
        """ """
        input = """int main(){
            a==b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("==",Id("a"),Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 321))
    def testAST_22(self):
        """ """
        input = """int main(){
           a!=b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("!=",Id("a"),Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 322))
    def testAST_23(self):
        """ """
        input = """int main(){
           a && b && c;
           a<b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("&&",BinaryOp("&&",Id("a"),Id("b")),Id("c")),BinaryOp("<",Id("a"),Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 323))
    def testAST_24(self):
        """ """
        input = """int main(){
            a<=3;
            a && b && c;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("<=",Id("a"),IntLiteral(3)),BinaryOp("&&",BinaryOp("&&",Id("a"),Id("b")),Id("c"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 324))
    def testAST_25(self):
        """ """
        input = """int main(){
           x<=5=4;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",BinaryOp("<=",Id("x"),IntLiteral(5)),IntLiteral(4))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 325))
    def testAST_26(self):
        """ """
        input = """int main(){
           a/b/c;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("/",BinaryOp("/",Id("a"),Id("b")),Id("c"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 326))
    def testAST_27(self):
        """ """
        input = """int main(){
           a && b && c || a*b*c;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("||",BinaryOp("&&",BinaryOp("&&",Id("a"),Id("b")),Id("c")),BinaryOp("*",BinaryOp("*",Id("a"),Id("b")),Id("c")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 327))
    def testAST_28(self):
        """ """
        input = """int main(){
           -a;
           !b;
           c+a+b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([UnaryOp("-",Id("a")),UnaryOp("!",Id("b")),BinaryOp("+",BinaryOp("+",Id("c"),Id("a")),Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 328))
    def testAST_29(self):
        """ """
        input = """int main(){
           a=2+3+4+b+g+d+f;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",IntLiteral(2),IntLiteral(3)),IntLiteral(4)),Id("b")),Id("g")),Id("d")),Id("f")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 329))
    def testAST_30(self):
        """ """
        input = """int main(){
           foo(2)[x+3];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 330))
    def testAST_31(self):
        """ """
        input = """int main(){
            2+foo(a+b,c+d); 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("+",IntLiteral(2),CallExpr(Id("foo"),[BinaryOp("+",Id("a"),Id("b")),BinaryOp("+",Id("c"),Id("d"))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 331))
    def testAST_32(self):
        """ """
        input = """int main(){
            a = b || c && d;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("||",Id("b"),BinaryOp("&&",Id("c"),Id("d"))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 332))
    def testAST_33(self):
        """ """
        input = """int main(){
           foo(2)[x+3];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 333))
    def testAST_34(self):
        """ """
        input = """int main(){
            2+3*4-8/2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("-",BinaryOp("+",IntLiteral(2),BinaryOp("*",IntLiteral(3),IntLiteral(4))),BinaryOp("/",IntLiteral(8),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 334))
    def testAST_35(self):
        """ """
        input = """void main(){
             b || c && d + foo(2)[x+3];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("||",Id("b"),BinaryOp("&&",Id("c"),BinaryOp("+",Id("d"),ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 335))
    def testAST_36(self):
        """ """
        input = """int main(){
            foo(2)[x+3]+2*5-6/3;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("-",BinaryOp("+",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3))),BinaryOp("*",IntLiteral(2),IntLiteral(5))),BinaryOp("/",IntLiteral(6),IntLiteral(3)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 336))
    def testAST_37(self):
        """ """
        input = """int main(){
            (2 - 1) && d + foo(2)[x+3];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("&&",BinaryOp("-",IntLiteral(2),IntLiteral(1)),BinaryOp("+",Id("d"),ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 337))
    def testAST_38(self):
        """ """
        input = """void main(){
           a=sub()[(1)];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),ArrayCell(CallExpr(Id("sub"),[]),IntLiteral(1)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 338))
    def testAST_39(self):
        """ """
        input = """int a,b,c,d,e,f[100];
        boolean check;
        void main(){
            if (check==false) a=a+b+c+d[5]; else a=a-b-c-d[5];
        }"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",IntType()),VarDecl("e",IntType()),VarDecl("f",ArrayType(100,IntType())),VarDecl("check",BoolType()),FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp("==",Id("check"),BooleanLiteral(False)),BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),ArrayCell(Id("d"),IntLiteral(5)))),BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("-",BinaryOp("-",Id("a"),Id("b")),Id("c")),ArrayCell(Id("d"),IntLiteral(5)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 339))
    def testAST_40(self):
        """ """
        input = """int main(){
            int a,b,c;
            a=1;
            b=2;
            c=3;
            if (a<b) print(); else {}
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),BinaryOp("=",Id("c"),IntLiteral(3)),If(BinaryOp("<",Id("a"),Id("b")),CallExpr(Id("print"),[]),Block([]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 340))
    def testAST_41(self):
        """ """
        input = """void main(){
            int a,b,c;
            a=1;
            b=2;
            c=3;
            if (a<(b<c)) print(); else {}
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),BinaryOp("=",Id("c"),IntLiteral(3)),If(BinaryOp("<",Id("a"),BinaryOp("<",Id("b"),Id("c"))),CallExpr(Id("print"),[]),Block([]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 341))
    def testAST_42(self):
        """ """
        input = """void main(){
            int a,b,c;
            a=1;
            b=2;
            c=3;
            do {
                a!=b;
            } while a<2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),BinaryOp("=",Id("c"),IntLiteral(3)),Dowhile([Block([BinaryOp("!=",Id("a"),Id("b"))])],BinaryOp("<",Id("a"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 342))
    def testAST_43(self):
        """ """
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do {
                    if (a=10) {} else break;
                } while a>1;
            }
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],FloatType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(10)),Block([VarDecl("a",ArrayType(5,IntType()))]),Block([Dowhile([Block([If(BinaryOp("=",Id("a"),IntLiteral(10)),Block([]),Break())])],BinaryOp(">",Id("a"),IntLiteral(1)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 343))
    def testAST_44(self):
        """ """
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do {
                    if (a=10) {
                        if (a==2) {
                            for (x;y;z) {
                                for(a;b;c){
                                    for (t;u;v) {
                                        break;
                                    }
                                }
                            }
                        }
                    } else break;
                    a=a-1;
                } while a>0;
            }
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],FloatType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(10)),Block([VarDecl("a",ArrayType(5,IntType()))]),Block([Dowhile([Block([If(BinaryOp("=",Id("a"),IntLiteral(10)),Block([If(BinaryOp("==",Id("a"),IntLiteral(2)),Block([For(Id("x"),Id("y"),Id("z"),Block([For(Id("a"),Id("b"),Id("c"),Block([For(Id("t"),Id("u"),Id("v"),Block([Break()]))]))]))]))]),Break()),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1)))])],BinaryOp(">",Id("a"),IntLiteral(0)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 344))
    def testAST_45(self):
        """ """
        input = """int main(){
            do{
                string a,b;
                a="test";
                b="thu";
            }
            {

            }while(a==b);
          
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([VarDecl("a",StringType()),VarDecl("b",StringType()),BinaryOp("=",Id("a"),StringLiteral("test")),BinaryOp("=",Id("b"),StringLiteral("thu"))]),Block([])],BinaryOp("==",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 345))
    def testAST_46(self):
        """ """
        input = """void main(){
          float a,b;
          a=1.3;
          b=1.2;
          print(a+b);
          if (a>=b) {
              continue;
          } else return;
          for (i=0;i<=10;i=i+1) {
              print(i);
          }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",FloatType()),VarDecl("b",FloatType()),BinaryOp("=",Id("a"),FloatLiteral(1.3)),BinaryOp("=",Id("b"),FloatLiteral(1.2)),CallExpr(Id("print"),[BinaryOp("+",Id("a"),Id("b"))]),If(BinaryOp(">=",Id("a"),Id("b")),Block([Continue()]),Return()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<=",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("print"),[Id("i")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 346))
    def testAST_47(self):
        """ """
        input = """void sub() {
            a=1;
            if (!a) return; 
            else return 2; 
        }"""
        expect = str(Program([FuncDecl(Id("sub"),[],VoidType(),Block([BinaryOp("=",Id("a"),IntLiteral(1)),If(UnaryOp("!",Id("a")),Return(),Return(IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 347))
    def testAST_48(self):
        """ """
        input = """int[] check(int b[]) {
        int a[1];
        boolean c;
        c=true;
        if (!c) return a;
        else return b ;
        }"""
        expect = str(Program([FuncDecl(Id("check"),[VarDecl("b",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([VarDecl("a",ArrayType(1,IntType())),VarDecl("c",BoolType()),BinaryOp("=",Id("c"),BooleanLiteral(True)),If(UnaryOp("!",Id("c")),Return(Id("a")),Return(Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 348))
    def testAST_49(self):
        """ """
        input = """int add(int a,int b){
            return a+b;
        }
            void main(){
                a=5;
                b=6;
                print(add(a,b));
            }"""
        expect = str(Program([FuncDecl(Id("add"),[VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([Return(BinaryOp("+",Id("a"),Id("b")))])),FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),IntLiteral(5)),BinaryOp("=",Id("b"),IntLiteral(6)),CallExpr(Id("print"),[CallExpr(Id("add"),[Id("a"),Id("b")])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 349))
    def testAST_50(self):
        """ """
        input = """float test(){
            foo(2)[a[2+x]] = a[b[2]] +3;
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],FloatType(),Block([BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),ArrayCell(Id("a"),BinaryOp("+",IntLiteral(2),Id("x")))),BinaryOp("+",ArrayCell(Id("a"),ArrayCell(Id("b"),IntLiteral(2))),IntLiteral(3)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 350))
    def testAST_51(self):
        """ """
        input = """string add(string a,string b){
            return a+b;
        }
            void main(){
                a="thu";
                b="xem";
                print(add(a,b));
            }"""
        expect = str(Program([FuncDecl(Id("add"),[VarDecl("a",StringType()),VarDecl("b",StringType())],StringType(),Block([Return(BinaryOp("+",Id("a"),Id("b")))])),FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),StringLiteral("thu")),BinaryOp("=",Id("b"),StringLiteral("xem")),CallExpr(Id("print"),[CallExpr(Id("add"),[Id("a"),Id("b")])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 351))
    def testAST_52(self):
        """ """
        input = """void main(){
            int array[5];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("array",ArrayType(5,IntType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 352))
    def testAST_53(self):
        """ """
        input = """void main(){
           int a,b,c;
           a=b=c=1;
           float f[6];
           if (a==b) f[0]=1;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),BinaryOp("=",Id("a"),BinaryOp("=",Id("b"),BinaryOp("=",Id("c"),IntLiteral(1)))),VarDecl("f",ArrayType(6,FloatType())),If(BinaryOp("==",Id("a"),Id("b")),BinaryOp("=",ArrayCell(Id("f"),IntLiteral(0)),IntLiteral(1)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 353))
    def testAST_54(self):
        """ """
        input = """void cacul(int a,int b,int c){
            if ((a<b)<c) {
                for (i=0;i<10000000000;i=i+1){
                    for (j=0;j<10000000000;j=j+1){
                        for (k=0;k<10000000000;k=k+1) {
                            for (l=0;l<10000000000;l=l+1) {
                                for (m=0;m<10000000000;m=m+1) {
                                    for (n=0;n<10000000000;n=n+1) {
                                        if (i==9999999999) break; else {
                                            print(a+b+c);
                                            }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }   
        void main(){
            cacul(999999999999999999999999999999,99999999999999999999,9999999999);
        }"""
        expect = str(Program([FuncDecl(Id("cacul"),[VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType())],VoidType(),Block([If(BinaryOp("<",BinaryOp("<",Id("a"),Id("b")),Id("c")),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10000000000)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),IntLiteral(10000000000)),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([For(BinaryOp("=",Id("k"),IntLiteral(0)),BinaryOp("<",Id("k"),IntLiteral(10000000000)),BinaryOp("=",Id("k"),BinaryOp("+",Id("k"),IntLiteral(1))),Block([For(BinaryOp("=",Id("l"),IntLiteral(0)),BinaryOp("<",Id("l"),IntLiteral(10000000000)),BinaryOp("=",Id("l"),BinaryOp("+",Id("l"),IntLiteral(1))),Block([For(BinaryOp("=",Id("m"),IntLiteral(0)),BinaryOp("<",Id("m"),IntLiteral(10000000000)),BinaryOp("=",Id("m"),BinaryOp("+",Id("m"),IntLiteral(1))),Block([For(BinaryOp("=",Id("n"),IntLiteral(0)),BinaryOp("<",Id("n"),IntLiteral(10000000000)),BinaryOp("=",Id("n"),BinaryOp("+",Id("n"),IntLiteral(1))),Block([If(BinaryOp("==",Id("i"),IntLiteral(9999999999)),Break(),Block([CallExpr(Id("print"),[BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c"))])]))]))]))]))]))]))]))]))])),FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("cacul"),[IntLiteral(999999999999999999999999999999),IntLiteral(99999999999999999999),IntLiteral(9999999999)])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 354))
    def testAST_55(self):
        """ """
        input = """int main(){
            b[c[d(100000000000000000000000000)]];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([ArrayCell(Id("b"),ArrayCell(Id("c"),CallExpr(Id("d"),[IntLiteral(100000000000000000000000000)])))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 355))
    def testAST_56(self):
        """ """
        input = """void main(){
           test();
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("test"),[])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 356))
    def testAST_57(self):
        """ """
        input = """void main(){
            a = 1 +5+6*(2-3 + 4 - 5 + (6*3/2-1));
            b = d(arr[3]);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(5)),BinaryOp("*",IntLiteral(6),BinaryOp("+",BinaryOp("-",BinaryOp("+",BinaryOp("-",IntLiteral(2),IntLiteral(3)),IntLiteral(4)),IntLiteral(5)),BinaryOp("-",BinaryOp("/",BinaryOp("*",IntLiteral(6),IntLiteral(3)),IntLiteral(2)),IntLiteral(1)))))),BinaryOp("=",Id("b"),CallExpr(Id("d"),[ArrayCell(Id("arr"),IntLiteral(3))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 357))
    def testAST_58(self):
        """ """
        input = """int main(){
        arr[foo()]==b=a;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",BinaryOp("==",ArrayCell(Id("arr"),CallExpr(Id("foo"),[])),Id("b")),Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 358))
    def testAST_59(self):
        """ """
        input = """void main(){
           a=1+2+a(3+4,5+6,b+c);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(2)),CallExpr(Id("a"),[BinaryOp("+",IntLiteral(3),IntLiteral(4)),BinaryOp("+",IntLiteral(5),IntLiteral(6)),BinaryOp("+",Id("b"),Id("c"))])))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 359))
    def testAST_60(self):
        """ """
        input = """void main()
        {
            a= "string"[3] + "name";
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",ArrayCell(StringLiteral("string"),IntLiteral(3)),StringLiteral("name")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 360))
    def testAST_61(self):
        """ """
        input = """int main (){
            a= foo()[foo()[foo(0)]];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),ArrayCell(CallExpr(Id("foo"),[]),ArrayCell(CallExpr(Id("foo"),[]),CallExpr(Id("foo"),[IntLiteral(0)]))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 361))
    def testAST_62(self):
        """ """
        input = """int main(){
            float x;
            x=1.2e3;
            (a+b)[12];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("x",FloatType()),BinaryOp("=",Id("x"),FloatLiteral(1200.0)),ArrayCell(BinaryOp("+",Id("a"),Id("b")),IntLiteral(12))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 362))
    def testAST_63(self):
        """ """
        input = """int main(){
            string a;
            a="Hello";
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",StringType()),BinaryOp("=",Id("a"),StringLiteral("Hello"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 363))
    def testAST_64(self):
        """ """
        input = """void main(){
           ------1;
           a!=b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",IntLiteral(1))))))),BinaryOp("!=",Id("a"),Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 364))
    def testAST_65(self):
        """ """
        input = """float test(){
            if (exp) if (exp) {} else {} 
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],FloatType(),Block([If(Id("exp"),If(Id("exp"),Block([]),Block([])))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 365))
    def testAST_66(self):
        """ """
        input = """void check() {
            a=1;
            b=2;
            if (a=b) return; 
            else return 2; 
        }"""
        expect = str(Program([FuncDecl(Id("check"),[],VoidType(),Block([BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),If(BinaryOp("=",Id("a"),Id("b")),Return(),Return(IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 366))
    def testAST_67(self):
        """ """
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do { a=b;}
                    
                 while a>0;
            }
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],FloatType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(10)),Block([VarDecl("a",ArrayType(5,IntType()))]),Block([Dowhile([Block([BinaryOp("=",Id("a"),Id("b"))])],BinaryOp(">",Id("a"),IntLiteral(0)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 367))
    def testAST_68(self):
        """ """
        input = """int main(){
            b=8;
            a=(((((n/2)))));
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("b"),IntLiteral(8)),BinaryOp("=",Id("a"),BinaryOp("/",Id("n"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 368))
    def testAST_69(self):
        """ """
        input = """int main(string a[], int a,int b){
            a || b || c || d || f || g && h && J && k && d;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",ArrayPointerType(StringType())),VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([BinaryOp("||",BinaryOp("||",BinaryOp("||",BinaryOp("||",BinaryOp("||",Id("a"),Id("b")),Id("c")),Id("d")),Id("f")),BinaryOp("&&",BinaryOp("&&",BinaryOp("&&",BinaryOp("&&",Id("g"),Id("h")),Id("J")),Id("k")),Id("d")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 369))
    def testAST_70(self):
        """ """
        input = """int main(){
            if (a) if (a) if (a) if (a) a=a+2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(Id("a"),If(Id("a"),If(Id("a"),If(Id("a"),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(2)))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 370))
    def testAST_71(self):
        """ """
        input = """int main(){
            int a;
            a = (3 - 2 -9)/(2*3*5/10);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),BinaryOp("=",Id("a"),BinaryOp("/",BinaryOp("-",BinaryOp("-",IntLiteral(3),IntLiteral(2)),IntLiteral(9)),BinaryOp("/",BinaryOp("*",BinaryOp("*",IntLiteral(2),IntLiteral(3)),IntLiteral(5)),IntLiteral(10))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 371))
    def testAST_72(self):
        """ """
        input = """void main(){
            for(i = 0; i < 10000; i=i+1)
                sum =sum + a[i];
            printf("%d",sum);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10000)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),ArrayCell(Id("a"),Id("i"))))),CallExpr(Id("printf"),[StringLiteral("%d"),Id("sum")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 372))
    def testAST_73(self):
        """ """
        input = """int main(){
            foo(2)[3+x] = a[b[2]] +3;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",IntLiteral(3),Id("x"))),BinaryOp("+",ArrayCell(Id("a"),ArrayCell(Id("b"),IntLiteral(2))),IntLiteral(3)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 373))
    def testAST_74(self):
        """ """
        input = """int[] test(int b[], int c[]){
            a=1+2*4/1;
            ----------------------------------------9;
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("b",ArrayPointerType(IntType())),VarDecl("c",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([BinaryOp("=",Id("a"),BinaryOp("+",IntLiteral(1),BinaryOp("/",BinaryOp("*",IntLiteral(2),IntLiteral(4)),IntLiteral(1)))),UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",IntLiteral(9)))))))))))))))))))))))))))))))))))))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 374))
    def testAST_75(self):
        """ """
        input = """int main(){
            check=false;
            if (check) a=1+2*3/4-6;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("check"),BooleanLiteral(False)),If(Id("check"),BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("+",IntLiteral(1),BinaryOp("/",BinaryOp("*",IntLiteral(2),IntLiteral(3)),IntLiteral(4))),IntLiteral(6))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 375))
    def testAST_76(self):
        """ """
        input = """int main()
        {
            int a;
            do {
                for (i=0;i<999999999999999;i=i+1){
                    for (j=0;j<100000000000;j=j+1){
                        for (k=0;k<9999999999999999;k=k+1){
                            for (l=0;l<1000000000000;l=l+1){
                                for (m=0;m<9999999999999;m=m+1){
                                    for (n=0;n<100000000000000;n=n+1){
                                            printf("Hello");
                                    }
                                }
                            }
                        }
                    }
                }
                a=a+1;
            } while a<999999999999999999999999999999999;
            
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),Dowhile([Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(999999999999999)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),IntLiteral(100000000000)),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([For(BinaryOp("=",Id("k"),IntLiteral(0)),BinaryOp("<",Id("k"),IntLiteral(9999999999999999)),BinaryOp("=",Id("k"),BinaryOp("+",Id("k"),IntLiteral(1))),Block([For(BinaryOp("=",Id("l"),IntLiteral(0)),BinaryOp("<",Id("l"),IntLiteral(1000000000000)),BinaryOp("=",Id("l"),BinaryOp("+",Id("l"),IntLiteral(1))),Block([For(BinaryOp("=",Id("m"),IntLiteral(0)),BinaryOp("<",Id("m"),IntLiteral(9999999999999)),BinaryOp("=",Id("m"),BinaryOp("+",Id("m"),IntLiteral(1))),Block([For(BinaryOp("=",Id("n"),IntLiteral(0)),BinaryOp("<",Id("n"),IntLiteral(100000000000000)),BinaryOp("=",Id("n"),BinaryOp("+",Id("n"),IntLiteral(1))),Block([CallExpr(Id("printf"),[StringLiteral("Hello")])]))]))]))]))]))])),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1)))])],BinaryOp("<",Id("a"),IntLiteral(999999999999999999999999999999999)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 376))
    def testAST_77(self):
        """ """
        input = """int main(){
            if (a) if (a) if (a) if (a) a=a+2; else a=a+1;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(Id("a"),If(Id("a"),If(Id("a"),If(Id("a"),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(2))),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1)))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 377))
    def testAST_78(self):
        """ """
        input = """void main(){
           a=1+2+a(a%b,c/d,0*9999999999999);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(2)),CallExpr(Id("a"),[BinaryOp("%",Id("a"),Id("b")),BinaryOp("/",Id("c"),Id("d")),BinaryOp("*",IntLiteral(0),IntLiteral(9999999999999))])))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 378))
    def testAST_79(self):
        """ """
        input = """void main(){
            int a[4],b[5],c[6],d;
            {
                a=2;
                b=3;
                c=4;
                d=a+b+c+d+e+f+g+i+k;
            }
            foo(2)[3+x] = a[b[2]] +3;
            if (a<b) c=a; else c=b;
            -a;
            !b;
            c+a+b;
            a && b && c;
            a<b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",ArrayType(4,IntType())),VarDecl("b",ArrayType(5,IntType())),VarDecl("c",ArrayType(6,IntType())),VarDecl("d",IntType()),Block([BinaryOp("=",Id("a"),IntLiteral(2)),BinaryOp("=",Id("b"),IntLiteral(3)),BinaryOp("=",Id("c"),IntLiteral(4)),BinaryOp("=",Id("d"),BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),Id("d")),Id("e")),Id("f")),Id("g")),Id("i")),Id("k")))]),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",IntLiteral(3),Id("x"))),BinaryOp("+",ArrayCell(Id("a"),ArrayCell(Id("b"),IntLiteral(2))),IntLiteral(3))),If(BinaryOp("<",Id("a"),Id("b")),BinaryOp("=",Id("c"),Id("a")),BinaryOp("=",Id("c"),Id("b"))),UnaryOp("-",Id("a")),UnaryOp("!",Id("b")),BinaryOp("+",BinaryOp("+",Id("c"),Id("a")),Id("b")),BinaryOp("&&",BinaryOp("&&",Id("a"),Id("b")),Id("c")),BinaryOp("<",Id("a"),Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 379))
    def testAST_80(self):
        """ """
        input = """void main(){
            a = 1 +5+6*(2-3 + 4 - 5 + (6*3/2-1));
            a=1;
            b=2;
            if (a=b) return; 
            else return 2;
            b = d(arr[3]);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(5)),BinaryOp("*",IntLiteral(6),BinaryOp("+",BinaryOp("-",BinaryOp("+",BinaryOp("-",IntLiteral(2),IntLiteral(3)),IntLiteral(4)),IntLiteral(5)),BinaryOp("-",BinaryOp("/",BinaryOp("*",IntLiteral(6),IntLiteral(3)),IntLiteral(2)),IntLiteral(1)))))),BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),If(BinaryOp("=",Id("a"),Id("b")),Return(),Return(IntLiteral(2))),BinaryOp("=",Id("b"),CallExpr(Id("d"),[ArrayCell(Id("arr"),IntLiteral(3))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 380))
    def testAST_81(self):
        """ """
        input = """void main(){
           ------1;
           a!=b;
        }
        int test(){
            int a,b;
                a=10;
                {
                    int a[5];
                }
                {
                    do { a=b;}
                        
                    while a>0;
                }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",IntLiteral(1))))))),BinaryOp("!=",Id("a"),Id("b"))])),FuncDecl(Id("test"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(10)),Block([VarDecl("a",ArrayType(5,IntType()))]),Block([Dowhile([Block([BinaryOp("=",Id("a"),Id("b"))])],BinaryOp(">",Id("a"),IntLiteral(0)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 381))
    def testAST_82(self):
        """ """
        input = """int main(){
            {
                {
                    {
                        {
                            {
                                {
                                    int a,b,c;
                                }
                            }
                        }
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Block([Block([Block([Block([Block([Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType())])])])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 382))
    def testAST_83(self):
        """ """
        input = """void main(){

            a = 1 +5+6*(2-3 + 4 - 5 + (6*3/2-1));
            {
                {
                    {
                        {
                            string a;
                            a="Hello";
                            float a,b;
                            a=1.3;
                            b=1.2;
                            print(a+b);
                            if (a>=b) {
                                continue;
                            } else return;
                            for (i=0;i<=10;i=i+1) {
                                print(i);
                            }
                        }
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(5)),BinaryOp("*",IntLiteral(6),BinaryOp("+",BinaryOp("-",BinaryOp("+",BinaryOp("-",IntLiteral(2),IntLiteral(3)),IntLiteral(4)),IntLiteral(5)),BinaryOp("-",BinaryOp("/",BinaryOp("*",IntLiteral(6),IntLiteral(3)),IntLiteral(2)),IntLiteral(1)))))),Block([Block([Block([Block([VarDecl("a",StringType()),BinaryOp("=",Id("a"),StringLiteral("Hello")),VarDecl("a",FloatType()),VarDecl("b",FloatType()),BinaryOp("=",Id("a"),FloatLiteral(1.3)),BinaryOp("=",Id("b"),FloatLiteral(1.2)),CallExpr(Id("print"),[BinaryOp("+",Id("a"),Id("b"))]),If(BinaryOp(">=",Id("a"),Id("b")),Block([Continue()]),Return()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<=",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("print"),[Id("i")])]))])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 383))
    def testAST_84(self):
        """ """
        input = """int[] test(){
            a=a[b[c[d[f[g[h[j[k[l(99999999999999999999999)]]]]]]]]];
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],ArrayPointerType(IntType()),Block([BinaryOp("=",Id("a"),ArrayCell(Id("a"),ArrayCell(Id("b"),ArrayCell(Id("c"),ArrayCell(Id("d"),ArrayCell(Id("f"),ArrayCell(Id("g"),ArrayCell(Id("h"),ArrayCell(Id("j"),ArrayCell(Id("k"),CallExpr(Id("l"),[IntLiteral(99999999999999999999999)])))))))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 384))
    def testAST_85(self):
        """ """
        input = """void main(){
            int a,b,c,d;
            a=1;
            b=2;
            c=3;
            d=5;
            if(a==1) if(b==2) if(c==3) d=d+1; else continue; else break;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",IntType()),BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),BinaryOp("=",Id("c"),IntLiteral(3)),BinaryOp("=",Id("d"),IntLiteral(5)),If(BinaryOp("==",Id("a"),IntLiteral(1)),If(BinaryOp("==",Id("b"),IntLiteral(2)),If(BinaryOp("==",Id("c"),IntLiteral(3)),BinaryOp("=",Id("d"),BinaryOp("+",Id("d"),IntLiteral(1))),Continue()),Break()))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 385))
    def testAST_86(self):
        """ """
        input = """int main(){
            do {
                    if (a=10) {
                        if (a==2) {
                            for (x;y;z) {
                                for(a;b;c){
                                    foo(10)[1+x] = a[b[c[d[g[2]]]]] +3;
                                        for (t;u;v) {
                                            break;
                                        }
                                }
                            }
                        }
                    } else break;
                    a=a-1;
                } while a>0;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([If(BinaryOp("=",Id("a"),IntLiteral(10)),Block([If(BinaryOp("==",Id("a"),IntLiteral(2)),Block([For(Id("x"),Id("y"),Id("z"),Block([For(Id("a"),Id("b"),Id("c"),Block([BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(10)]),BinaryOp("+",IntLiteral(1),Id("x"))),BinaryOp("+",ArrayCell(Id("a"),ArrayCell(Id("b"),ArrayCell(Id("c"),ArrayCell(Id("d"),ArrayCell(Id("g"),IntLiteral(2)))))),IntLiteral(3))),For(Id("t"),Id("u"),Id("v"),Block([Break()]))]))]))]))]),Break()),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1)))])],BinaryOp(">",Id("a"),IntLiteral(0)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 386))
    def testAST_87(self):
        """ """
        input = """
            int a,b,c;
            boolean check(int n){
                if (x<2) return 0;
                for (i=0; i<sqrt(n); i=i+1) {
                    if (n%i==0) return 1;
                }
            }
            void main(){
                int n;
                n=10;
                check(10);
            }
        """
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),FuncDecl(Id("check"),[VarDecl("n",IntType())],BoolType(),Block([If(BinaryOp("<",Id("x"),IntLiteral(2)),Return(IntLiteral(0))),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),CallExpr(Id("sqrt"),[Id("n")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("n"),Id("i")),IntLiteral(0)),Return(IntLiteral(1)))]))])),FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("n",IntType()),BinaryOp("=",Id("n"),IntLiteral(10)),CallExpr(Id("check"),[IntLiteral(10)])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 387))
    def testAST_88(self):
        """ """
        input = """void main(){
            int a,b;
            b=10;
            c=3;
            string a;
            a="Hello World";
            if (b==10) {
                break;
            } else {
                if (c==2) {
                    for (i=0; i<9999999999999999999999;i=i+1){
                        for (i=0; i<9999999999999999999999;i=i+1){
                            for (i=0; i<9999999999999999999999;i=i+1){
                                for (i=0; i<9999999999999999999999;i=i+1){
                                    print("%s",a);
                                }   
                            }
                        }
                    } 
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("b"),IntLiteral(10)),BinaryOp("=",Id("c"),IntLiteral(3)),VarDecl("a",StringType()),BinaryOp("=",Id("a"),StringLiteral("Hello World")),If(BinaryOp("==",Id("b"),IntLiteral(10)),Block([Break()]),Block([If(BinaryOp("==",Id("c"),IntLiteral(2)),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(9999999999999999999999)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(9999999999999999999999)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(9999999999999999999999)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(9999999999999999999999)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("print"),[StringLiteral("%s"),Id("a")])]))]))]))]))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 388))
    def testAST_89(self):
        """ """
        input = """void foo(float a[]){
            float y[10];
            foo(x); 
            foo(y);
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("a",ArrayPointerType(FloatType()))],VoidType(),Block([VarDecl("y",ArrayType(10,FloatType())),CallExpr(Id("foo"),[Id("x")]),CallExpr(Id("foo"),[Id("y")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 389))
    def testAST_90(self):
        """ """
        input = """int Muil(int a,int b){
            return a*b;
        }
            void main(){
                a=5;
                b=6;
                print(Muil(a,b));
            }"""
        expect = str(Program([FuncDecl(Id("Muil"),[VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([Return(BinaryOp("*",Id("a"),Id("b")))])),FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),IntLiteral(5)),BinaryOp("=",Id("b"),IntLiteral(6)),CallExpr(Id("print"),[CallExpr(Id("Muil"),[Id("a"),Id("b")])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 390))
    def testAST_91(self):
        """ """
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do {
                    if (a=10) {} else break;
                } while a>1;
            }
            int a,b,c;
            a=1;
            b=2;
            c=3;
            do {
                a!=b;
            } while a<2;
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],FloatType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(10)),Block([VarDecl("a",ArrayType(5,IntType()))]),Block([Dowhile([Block([If(BinaryOp("=",Id("a"),IntLiteral(10)),Block([]),Break())])],BinaryOp(">",Id("a"),IntLiteral(1)))]),VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp("=",Id("b"),IntLiteral(2)),BinaryOp("=",Id("c"),IntLiteral(3)),Dowhile([Block([BinaryOp("!=",Id("a"),Id("b"))])],BinaryOp("<",Id("a"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 391))
    def testAST_92(self):
        """ """
        input = """void main(){
            b || c && d + foo(2)[x+3];
            (2 - 1) && d + foo(2)[x+3];
            a=add()[(99999)];
            if (check==false) a=a+b+c+d[5]; else a=a-b-c-d[5];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("||",Id("b"),BinaryOp("&&",Id("c"),BinaryOp("+",Id("d"),ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3)))))),BinaryOp("&&",BinaryOp("-",IntLiteral(2),IntLiteral(1)),BinaryOp("+",Id("d"),ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),BinaryOp("+",Id("x"),IntLiteral(3))))),BinaryOp("=",Id("a"),ArrayCell(CallExpr(Id("add"),[]),IntLiteral(99999))),If(BinaryOp("==",Id("check"),BooleanLiteral(False)),BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),ArrayCell(Id("d"),IntLiteral(5)))),BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("-",BinaryOp("-",Id("a"),Id("b")),Id("c")),ArrayCell(Id("d"),IntLiteral(5)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 392))
    def testAST_93(self):
        """ """
        input = """int test() {
            a=1;
            if (!a) return; 
            else return 2;
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],IntType(),Block([BinaryOp("=",Id("a"),IntLiteral(1)),If(UnaryOp("!",Id("a")),Return(),Return(IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 393))    
    def testAST_94(self):
        """ """
        input = """void main(){
            int a[1];
            boolean c;
            c=true;
            if (!c) break;
            else continue;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",ArrayType(1,IntType())),VarDecl("c",BoolType()),BinaryOp("=",Id("c"),BooleanLiteral(True)),If(UnaryOp("!",Id("c")),Break(),Continue())]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 394))
    def testAST_95(self):
        """ """
        input = """float test(int a,float b){
            int a,b;
            a=10;
            {
                int a[5];
            }
            {
                do {
                    printf("%d",a);
                }
                    
                 while a>1;
            }
        }"""
        expect = str(Program([FuncDecl(Id("test"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],FloatType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(10)),Block([VarDecl("a",ArrayType(5,IntType()))]),Block([Dowhile([Block([CallExpr(Id("printf"),[StringLiteral("%d"),Id("a")])])],BinaryOp(">",Id("a"),IntLiteral(1)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 395))
    def testAST_96(self):
        """ """
        input = """int main(){
            a=b--1--c--3;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("-",BinaryOp("-",Id("b"),UnaryOp("-",IntLiteral(1))),UnaryOp("-",Id("c"))),UnaryOp("-",IntLiteral(3))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 396))
    def testAST_97(self):
        """ """
        input = """void main(){
            i=999999;
            for (i;i>1000;i=i-1){

            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("i"),IntLiteral(999999)),For(Id("i"),BinaryOp(">",Id("i"),IntLiteral(1000)),BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(1))),Block([]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 397))
    def testAST_98(self):
        """ """
        input = """boolean[] check(float a[],string b[]){

        }"""
        expect = str(Program([FuncDecl(Id("check"),[VarDecl("a",ArrayPointerType(FloatType())),VarDecl("b",ArrayPointerType(StringType()))],ArrayPointerType(BoolType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 398))
    def testAST_99(self):
        """ """
        input = """void main(){
            a=a[b[c[d[f[g[h[j[k[l(99999999999999999999999)]]]]]]]]];
            a = 1 +5+6*(2-3 + 4 - 5 + (6*3/2-1));
            {
                {
                    {
                        {
                            string a;
                            a="Hello";
                            float a,b;
                            a=1.3;
                            b=1.2;
                            print(a+b);
                            if (a>=b) {
                                continue;
                            } else return;
                            for (i=0;i<=10;i=i+1) {
                                print(i);
                            }
                        }
                    }
                }
            }
            a=(((((((((((((((((((((((((((((n*2)))))))))))))))))))))))))))));
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),ArrayCell(Id("a"),ArrayCell(Id("b"),ArrayCell(Id("c"),ArrayCell(Id("d"),ArrayCell(Id("f"),ArrayCell(Id("g"),ArrayCell(Id("h"),ArrayCell(Id("j"),ArrayCell(Id("k"),CallExpr(Id("l"),[IntLiteral(99999999999999999999999)]))))))))))),BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(5)),BinaryOp("*",IntLiteral(6),BinaryOp("+",BinaryOp("-",BinaryOp("+",BinaryOp("-",IntLiteral(2),IntLiteral(3)),IntLiteral(4)),IntLiteral(5)),BinaryOp("-",BinaryOp("/",BinaryOp("*",IntLiteral(6),IntLiteral(3)),IntLiteral(2)),IntLiteral(1)))))),Block([Block([Block([Block([VarDecl("a",StringType()),BinaryOp("=",Id("a"),StringLiteral("Hello")),VarDecl("a",FloatType()),VarDecl("b",FloatType()),BinaryOp("=",Id("a"),FloatLiteral(1.3)),BinaryOp("=",Id("b"),FloatLiteral(1.2)),CallExpr(Id("print"),[BinaryOp("+",Id("a"),Id("b"))]),If(BinaryOp(">=",Id("a"),Id("b")),Block([Continue()]),Return()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<=",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("print"),[Id("i")])]))])])])]),BinaryOp("=",Id("a"),BinaryOp("*",Id("n"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 399))
    def testAST_100(self):
        """ """
        input = """void main(){
            int a;
            do {
                for (i=0;i<999999999999999;i=i+1){
                    for (j=0;j<100000000000;j=j+1){
                        for (k=0;k<9999999999999999;k=k+1){
                            for (l=0;l<1000000000000;l=l+1){
                                for (m=0;m<9999999999999;m=m+1){
                                    for (n=0;n<100000000000000;n=n+1){
                                            printf("Hello");
                                    }
                                }
                            }
                        }
                    }
                }
                a=a+1;
            } while a<999999999999999999999999999999999;
            if ((a<b)<c) {
                for (i=0;i<10000000000;i=i+1){
                    for (j=0;j<10000000000;j=j+1){
                        for (k=0;k<10000000000;k=k+1) {
                            for (l=0;l<10000000000;l=l+1) {
                                for (m=0;m<10000000000;m=m+1) {
                                    for (n=0;n<10000000000;n=n+1) {
                                        if (i==9999999999) break; else {
                                            print(a+b+c);
                                            }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            do {
                    if (a=10) {
                        if (a==2) {
                            for (x;y;z) {
                                for(a;b;c){
                                    foo(10)[1+x] = a[b[c[d[g[2]]]]] +3;
                                        for (t;u;v) {
                                            break;
                                        }
                                }
                            }
                        }
                    } else break;
                    a=a-1;
                } while a>0;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),Dowhile([Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(999999999999999)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),IntLiteral(100000000000)),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([For(BinaryOp("=",Id("k"),IntLiteral(0)),BinaryOp("<",Id("k"),IntLiteral(9999999999999999)),BinaryOp("=",Id("k"),BinaryOp("+",Id("k"),IntLiteral(1))),Block([For(BinaryOp("=",Id("l"),IntLiteral(0)),BinaryOp("<",Id("l"),IntLiteral(1000000000000)),BinaryOp("=",Id("l"),BinaryOp("+",Id("l"),IntLiteral(1))),Block([For(BinaryOp("=",Id("m"),IntLiteral(0)),BinaryOp("<",Id("m"),IntLiteral(9999999999999)),BinaryOp("=",Id("m"),BinaryOp("+",Id("m"),IntLiteral(1))),Block([For(BinaryOp("=",Id("n"),IntLiteral(0)),BinaryOp("<",Id("n"),IntLiteral(100000000000000)),BinaryOp("=",Id("n"),BinaryOp("+",Id("n"),IntLiteral(1))),Block([CallExpr(Id("printf"),[StringLiteral("Hello")])]))]))]))]))]))])),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1)))])],BinaryOp("<",Id("a"),IntLiteral(999999999999999999999999999999999))),If(BinaryOp("<",BinaryOp("<",Id("a"),Id("b")),Id("c")),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10000000000)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),IntLiteral(10000000000)),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([For(BinaryOp("=",Id("k"),IntLiteral(0)),BinaryOp("<",Id("k"),IntLiteral(10000000000)),BinaryOp("=",Id("k"),BinaryOp("+",Id("k"),IntLiteral(1))),Block([For(BinaryOp("=",Id("l"),IntLiteral(0)),BinaryOp("<",Id("l"),IntLiteral(10000000000)),BinaryOp("=",Id("l"),BinaryOp("+",Id("l"),IntLiteral(1))),Block([For(BinaryOp("=",Id("m"),IntLiteral(0)),BinaryOp("<",Id("m"),IntLiteral(10000000000)),BinaryOp("=",Id("m"),BinaryOp("+",Id("m"),IntLiteral(1))),Block([For(BinaryOp("=",Id("n"),IntLiteral(0)),BinaryOp("<",Id("n"),IntLiteral(10000000000)),BinaryOp("=",Id("n"),BinaryOp("+",Id("n"),IntLiteral(1))),Block([If(BinaryOp("==",Id("i"),IntLiteral(9999999999)),Break(),Block([CallExpr(Id("print"),[BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c"))])]))]))]))]))]))]))]))])),Dowhile([Block([If(BinaryOp("=",Id("a"),IntLiteral(10)),Block([If(BinaryOp("==",Id("a"),IntLiteral(2)),Block([For(Id("x"),Id("y"),Id("z"),Block([For(Id("a"),Id("b"),Id("c"),Block([BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(10)]),BinaryOp("+",IntLiteral(1),Id("x"))),BinaryOp("+",ArrayCell(Id("a"),ArrayCell(Id("b"),ArrayCell(Id("c"),ArrayCell(Id("d"),ArrayCell(Id("g"),IntLiteral(2)))))),IntLiteral(3))),For(Id("t"),Id("u"),Id("v"),Block([Break()]))]))]))]))]),Break()),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1)))])],BinaryOp(">",Id("a"),IntLiteral(0)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 400))