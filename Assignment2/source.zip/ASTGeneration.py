
#-------------------MSSV:1710849---------------------

from MCVisitor import MCVisitor
from MCParser import MCParser
from AST import *

class ASTGeneration(MCVisitor):
    def visitProgram(self,ctx:MCParser.ProgramContext):
        lstDecl = []
        for x in ctx.manyDecls():
            decl = self.visit(x)
            if type(decl) == type([]):
                lstDecl += decl
            else:
                lstDecl.append(decl)
        return Program(lstDecl)
    def visitManyDecls(self,ctx:MCParser.ManyDeclsContext):
        return self.visit(ctx.getChild(0))
    def visitVarDecls(self,ctx:MCParser.VarDeclsContext):
        types=self.visit(ctx.primitiveTypes())
        manyVar=self.visit(ctx.manyVar())
        lst=[]
        for x in manyVar:
            if isinstance(x,list):
                lst+=[VarDecl(x[0],ArrayType((int(x[1])),types))]
            else:
                lst+=[VarDecl(x,types)]
        return lst
    def visitManyVar(self,ctx:MCParser.ManyVarContext):
        return [self.visit(x) for x in ctx.var()]
    def visitVar(self,ctx:MCParser.VarContext):
        return [ctx.ID().getText()]+[ctx.INT_LIT().getText()] if ctx.INT_LIT() else ctx.ID().getText()
    def visitPrimitiveTypes(self,ctx:MCParser.PrimitiveTypesContext):
        return BoolType() if ctx.BOOLEAN() else IntType() if ctx.INT() else FloatType() if ctx.FLOAT() else StringType()
    def visitFuncDecls(self,ctx:MCParser.FuncDeclsContext):
        paraList=self.visit(ctx.paraList())
        types=self.visit(ctx.typeA())
        stmBlock=self.visit(ctx.stmBlock())
        return FuncDecl(Id(ctx.ID().getText()),paraList,types,stmBlock)
    def visitTypeA(self,ctx:MCParser.TypeAContext):
        return self.visit(ctx.primitiveTypes()) if ctx.primitiveTypes() else self.visit(ctx.outArrayPointerType()) if ctx.outArrayPointerType() else VoidType()
    def visitOutArrayPointerType(self,ctx:MCParser.OutArrayPointerTypeContext):
        return ArrayPointerType(self.visit(ctx.primitiveTypes()))
    def visitParaList(self,ctx:MCParser.ParaListContext):
        lstParaDecl=[]
        if ctx.paraDecl():
            for x in ctx.paraDecl():
                lstParaDecl+=self.visit(x)
        return lstParaDecl
    def visitParaDecl(self,ctx:MCParser.ParaDeclContext):
        types=self.visit(ctx.primitiveTypes())
        if ctx.LSP():
            return  [VarDecl(ctx.ID().getText(),ArrayPointerType(types))]
        else:
            return [VarDecl(ctx.ID().getText(),types)]
    def visitStmBlock(self,ctx:MCParser.StmBlockContext):
        lstBlock=[]
        if ctx.varDeclsStmList():
            for x in ctx.varDeclsStmList():
                block=self.visit(x) 
                if type(block)==type([]):
                    lstBlock+=block
                else:
                    lstBlock.append(block)
        return Block(lstBlock)
    def visitVarDeclsStmList(self,ctx:MCParser.VarDeclsStmListContext):
        return self.visit(ctx.getChild(0))
    def visitStm(self,ctx:MCParser.StmContext):
        return self.visit(ctx.getChild(0))
    def visitStmIf(self,ctx:MCParser.StmIfContext):
        return If(self.visit(ctx.exp()),self.visit(ctx.stm(0)),self.visit(ctx.stm(1)) if ctx.stm(1) else None)
    def visitStmDoWhile(self,ctx:MCParser.StmDoWhileContext):
        return Dowhile([self.visit(x) for x in ctx.stm()],self.visit(ctx.exp()))
    def visitStmFor(self,ctx:MCParser.StmForContext):
        return For(self.visit(ctx.exp(0)),self.visit(ctx.exp(1)),self.visit(ctx.exp(2)),self.visit(ctx.stm()))
    def visitStmBreak(self,ctx:MCParser.StmBreakContext):
        return Break()
    def visitStmContinue(self,ctx:MCParser.StmContinueContext):
        return Continue()
    def visitStmReturn(self,ctx:MCParser.StmReturnContext):
        return Return(self.visit(ctx.exp())) if ctx.exp() else Return()
    def visitStmExp(self,ctx:MCParser.StmExpContext):
        return self.visit(ctx.exp())
    def visitExp(self,ctx:MCParser.ExpContext):
        if ctx.ASSIGN():
            exp1=self.visit(ctx.exp1())
            exp=self.visit(ctx.exp())
            return BinaryOp(ctx.ASSIGN().getText(),exp1,exp)
        else:
            return self.visit(ctx.exp1())
    def visitExp1(self,ctx:MCParser.Exp1Context):
        if ctx.LOGIC_OR():
            exp2=self.visit(ctx.exp2())
            exp1=self.visit(ctx.exp1())
            return BinaryOp(ctx.LOGIC_OR().getText(),exp1,exp2)
        else:
            return self.visit(ctx.exp2())
    def visitExp2(self,ctx:MCParser.Exp2Context):
        if ctx.LOGIC_AND():
            exp2=self.visit(ctx.exp2())
            exp3=self.visit(ctx.exp3())
            return BinaryOp(ctx.LOGIC_AND().getText(),exp2,exp3)
        else:
            return self.visit(ctx.exp3())
    def visitExp3(self,ctx:MCParser.Exp3Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.exp4(0))
        else:
            exp4_0=self.visit(ctx.exp4(0))
            exp4_1=self.visit(ctx.exp4(1))
            return BinaryOp(ctx.getChild(1).getText(),exp4_0,exp4_1)
    def visitExp4(self,ctx:MCParser.Exp4Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.exp5(0))
        else:
            exp5_0=self.visit(ctx.exp5(0))
            exp5_1=self.visit(ctx.exp5(1))
            return BinaryOp(ctx.getChild(1).getText(),exp5_0,exp5_1)
    def visitExp5(self,ctx:MCParser.Exp5Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.exp6())
        else:
            exp5=self.visit(ctx.exp5())
            exp6=self.visit(ctx.exp6())
            return BinaryOp(ctx.getChild(1).getText(),exp5,exp6)
    def visitExp6(self,ctx:MCParser.Exp6Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.exp7())
        else:
            exp6=self.visit(ctx.exp6())
            exp7=self.visit(ctx.exp7())
            return BinaryOp(ctx.getChild(1).getText(),exp6,exp7)
    def visitExp7(self,ctx:MCParser.Exp7Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.exp8())
        else:
            exp7=self.visit(ctx.exp7())
            return UnaryOp(ctx.getChild(0).getText(),exp7)
    def visitExp8(self,ctx:MCParser.Exp8Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.exp9())
        else:
            exp=self.visit(ctx.exp())
            exp9=self.visit(ctx.exp9())
            return ArrayCell(exp9,exp)
    def visitExp9(self,ctx:MCParser.Exp9Context):
        if ctx.getChildCount()==1:
            return self.visit(ctx.operands())
        else:
            return self.visit(ctx.exp())
    def visitOperands(self,ctx:MCParser.OperandsContext):
        if ctx.literals():
            return self.visit(ctx.literals())
        elif ctx.funcCall():
            return self.visit(ctx.funcCall())
        else:
            return Id(ctx.ID().getText())
    def visitLiterals(self,ctx:MCParser.LiteralsContext):
        if ctx.INT_LIT():
            return IntLiteral(int(ctx.INT_LIT().getText()))
        elif ctx.FLOAT_LIT():
            return FloatLiteral(float(ctx.FLOAT_LIT().getText()))
        elif ctx.BOOLEAN_LIT():
            return BooleanLiteral(ctx.BOOLEAN_LIT().getText())
        else:
            return StringLiteral(ctx.STRING_LIT().getText())
    def visitFuncCall(self,ctx:MCParser.FuncCallContext):
        return CallExpr(Id(ctx.ID().getText()),self.visit(ctx.expList()))   
    def visitExpList(self,ctx:MCParser.ExpListContext):
        return [self.visit(x) for x in ctx.exp()]