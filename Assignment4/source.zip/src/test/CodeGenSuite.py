import unittest
from TestUtils import TestCodeGen
from AST import *


class CheckCodeGenSuite(unittest.TestCase):
    def test_int_literal(self):
        input = """
        void main(){
            putInt(10);
        }
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input, expect, 500))
    def test_ne_int_literal(self):
        input = """
            void main()
            {
                putIntLn(-13);
            }
        """
        expect = "-13\n"
        self.assertTrue(TestCodeGen.test(input,expect,501))
    def test_float_literal(self):
        input = """
            void main(){
                putFloatLn(1.0);
                putFloatLn(1e4);
                putFloatLn(1e-1);
                putFloat(1.e-1);
            }
        """
        expect = "1.0\n10000.0\n0.1\n0.1"
        self.assertTrue(TestCodeGen.test(input,expect,502))
    def test_boolean_literal(self):
        input = """
            void main()
            {
                putBool(false);
                putBool(true);
            }
        """
        expect = "falsetrue"
        self.assertTrue(TestCodeGen.test(input,expect,503))
    def test_string_literal(self):
        input = """
            void main()
            {
                putStringLn("check");
                putString("test");
            }
        """
        expect = "check\ntest"
        self.assertTrue(TestCodeGen.test(input,expect,504))
    def test_binary_op_with_add(self):
        input = """
            void main()
            {
                putIntLn(1 + 2);
                putFloatLn(1 + 2.0);
                putFloatLn(1.23 + -9.34);
                putFloat(1.2376 + -9);
            }
        """
        expect = "3\n3.0\n-8.110001\n-7.7624"
        self.assertTrue(TestCodeGen.test(input,expect,505))
    def test_binary_op_with_sub(self):
        input = """
            void main()
            {
                putIntLn(1 - 2);
                putFloatLn(1 - 2.0);
                putFloatLn(1.23 - -9.34);
                putFloat(1.2376 - -9);
            }
        """
        expect = "-1\n-1.0\n10.57\n10.2376"
        self.assertTrue(TestCodeGen.test(input,expect,506))
    def test_binary_op_with_divide(self):
        input = """
            void main()
            {
                putFloatLn(14/2);
                putFloatLn(13 / 2.08783);
                putFloatLn(158.2035564 / --236.256885);
                putFloat(122.23762 / ---9);
            }
        """
        expect = "7.0\n6.2265606\n0.66962516\n-13.581958"
        self.assertTrue(TestCodeGen.test(input,expect,507))
    def test_binary_op_with_mul(self):
        input = """
            void main()
            {
                putFloatLn(14/-2.0);
                putFloatLn(13 * 2.08783);
            }
        """
        expect = "-7.0\n27.14179\n"
        self.assertTrue(TestCodeGen.test(input,expect,508))
    def test_binary_op_add_int(self):
        input = """
            void main()
            {
                putInt(10+2);
            }
        """
        expect = "12"
        self.assertTrue(TestCodeGen.test(input,expect,509))
    def test_binary_op_sub(self):
        input = """
            void main()
            {
                putInt(100 - 2 * 12);
            }
        """
        expect = "76"
        self.assertTrue(TestCodeGen.test(input,expect,510))
    def test_binary_op_divide(self):
        input = """
            void main()
            {
                putFloat(47+30/16);
            }
        """
        expect = "48.0"
        self.assertTrue(TestCodeGen.test(input,expect,511))
    def test_binary_op_int(self):
        input = """
            void main()
            {
                putInt(100/2/4/5);
            }
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,512))
    def test_binary_op_boolean_1(self):
        input = """
            void main()
            {
                putBool(true && false);
            }
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input,expect,513))
    def test_binary_op_boolean_2(self):
        input = """
            void main()
            {
                putBool(5 <= 10);
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,514))
    def test_binary_op_boolean_3(self):
        input = """
            void main()
            {
                putBool(8==8);
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,515))
    def test_unary_op_with_not(self):
        input = """
            void main()
            {
                putBool(!(-10 == 2));
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,516))
    
    def test_unary_op_with_neg(self):
        input = """
            void main()
            {
                putIntLn(-11+4);
                putFloat(-12.3+12);
            }
        """
        expect = "-7\n-0.3000002"
        self.assertTrue(TestCodeGen.test(input,expect,517))
    
    def test_complex_and_op(self):
        input = """
            void main()
            {
                putBool(true && true || true);
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,518))
    
    def test_or_op(self):
        input = """
            void main()
            {
                putBoolLn(1 > 2 || 7 == 7);
                putBoolLn(1 < 0 ||-1 > 0);
                putBoolLn(1 > -0 || 2 >= 2);
            }
        """
        expect = "true\nfalse\ntrue\n"
        self.assertTrue(TestCodeGen.test(input,expect,519))
    
    def test_float_compare(self):
        input = """
             void main()
             {
                 putBool(1.23 <= 2.11);
             }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,520))
    def test_array_type__1(self):
        input = """
             void main()
             {
                 int a[1];
                 a[0] = 2;
                 putInt(a[0]);
             }
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,521))

    def test_dowhile_stmt__1(self):
        input = """
             void main()
             {
                int a,b;
                a=1;
                b = 0;
                do {
                   a=a+1;
                   b=2;
                } while (a>0);
                putInt(b);
             }
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,522))

    def test_for_stmt__1(self):
        input = """
            void main(){
                int a,b;
                b=0;
                for (a=0;a<10;a=a+1)
                {
                    b=10;
                }
                putInt(b);
            }
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input,expect,523))
    def test_assign_stmt__1(self):
        input = """
             void main()
             {
                int a;
                a=999;
                putInt(a);
             }
        """
        expect = "999"
        self.assertTrue(TestCodeGen.test(input,expect,524))
    def test_array_boolean(self):
        input = """
             int a[10];
             void main()
             {
                int i;
                for (i=0;i<10;i=i+1)
                {
                     a[i]=a[i]+1;
                }
                putBoolLn(a[2]);
                putBoolLn(a[3]);
             }
        """
        expect = "true\ntrue\n"
        self.assertTrue(TestCodeGen.test(input,expect,525))
    def test_array_int(self):
        input = """
             int a[11];
             void main()
             {
                int i;
                for (i=0;i<9;i=i+1)
                {
                     a[i]=10;
                }
                putIntLn(a[2]);
                putIntLn(a[3]);
             }
        """
        expect = "10\n10\n"
        self.assertTrue(TestCodeGen.test(input,expect,526))
    def test_pass_by_value_array_1(self):
        input = """
            void main()
            {
            int i;
            int c[6];
            
                for (i=0;i<5;i=i+1)
                {
                    c[i]=i+1;
                    putInt(c[i]);
                }
                
            }
        """
        expect = "12345"
        self.assertTrue(TestCodeGen.test(input,expect,527))
    def test_pass_by_value_array_2(self):
        input = """
            void main()
            {
                int i,a;
                int c[10];
                for (i=0;i<9;i=i+1)
                 {
                     c[i]=i+1;
                     putInt(c[i]);
                 }
                
                for (i=0;i<9;i=i+1)
                 {
                     putInt(c[i]);
                 }
            }
        """
        expect = "123456789123456789"
        self.assertTrue(TestCodeGen.test(input,expect,528))
    def test_while_1(self):
        input = """
            void main()
            {
                int a;
                a=10;
                do {
                    a=a-1;
                    putInt(a);
                } while (a>0);
                
            }
        """
        expect = "9876543210"
        self.assertTrue(TestCodeGen.test(input,expect,529))

    def test_for_stmt_1(self):
        input = """
            void main(){
                int i;
                for (i=0;i<10;i=i+1){
                    putInt(i-1);
                }
            }
        """
        expect = "-1012345678"
        self.assertTrue(TestCodeGen.test(input,expect,530))

    def test_for_stmt_2(self):
        input = """
            void main(){
                int i;
                for (i=0;i<10;i=i+1){
                    if ((i % 2) != 0){
                        putInt(i);
                    }
                }
            }    
        """
        expect = "13579"
        self.assertTrue(TestCodeGen.test(input,expect,531))
    def test_call_function_simple(self):
        input = """
        void foo(){
            return;
        }
        void main(){
            foo();
        }
        """
        expect = ""
        self.assertTrue(TestCodeGen.test(input,expect,532))
    def test_call_recursive(self):
        input = """
            int foo(int a){
                return a;
            }
            void main(){
                putInt(foo(foo(1)));
            }
        """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input,expect,533))
    def test_if_stmt_1(self):
        input = """ 
            void main(){
                int i;
                for (i=0;i<10;i=i+1)
                {
                    if (true){
                        putInt(i);
                    }
                }
            }
        """
        expect = "0123456789"
        self.assertTrue(TestCodeGen.test(input,expect,534))

    def test_if_stmt_2(self):
        input = """ 
            void main(){
                float a;
                a=0;
                if (true){
                    a=1.4;
                }
                putFloat(a);
            }
        """
        expect = "1.4"
        self.assertTrue(TestCodeGen.test(input,expect,535))
    def test_if_stmt_3(self):
        input = """ 
            float x;
            void main()
            {
                int a;
                a=-2;
                x=a*a;
                if (a<0)
                {
                    putFloat(x);
                }
                
            }
        """
        expect = "4.0"
        self.assertTrue(TestCodeGen.test(input,expect,536))
    def test_call_stmt_float_pass_int(self):
        input = """ 
            float a;
            void foo(float a,int b)
            {
                putFloatLn(a);
                putIntLn(b);
            }
            void main()
            {
                foo(1.2,1);
            }
        """
        expect = "1.2\n1\n"
        self.assertTrue(TestCodeGen.test(input,expect,537))
    def test_call_expr_float_pass_int_1(self):
        input = """ 
            float c;
            float foo(float a,int b)
            {
                return a;
            }
            void main()
            {
                c=foo(1.2,1);
                putFloat(c);
            }
        """
        expect = "1.2"
        self.assertTrue(TestCodeGen.test(input,expect,538))
    def test_if_stmt_6(self):
        input = """ 
            float x;
            void main()
            {
                int i;
                int x;
                x = 0;
                i = 1;
                if (i == 1){ 
                    putStringLn("dung");
                }
                else 
                {

                }
            }
        """
        expect = "dung\n"
        self.assertTrue(TestCodeGen.test(input,expect,539))
    def test_for_stmt_10(self):
        input = """ 
            void main()
            {
                int i;

                {
                    for (i=0;i<10;i=i+1)
                    {
                         putIntLn(i);
                    } 
                }
            }
        """
        expect = "0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n"
        self.assertTrue(TestCodeGen.test(input,expect,540))

    def test_for_stmt_11(self):
        input = """ 
            void main()
            {
                int i,j;
                {
                    for (i=0;i<10;i=i+1)
                    {
                         for (j=0;j<10;j=j+1)
                         {
                            putInt(j);
                         } 
                         putInt(i);
                    } 
                }
            }
        """
        expect = "01234567890012345678910123456789201234567893012345678940123456789501234567896012345678970123456789801234567899"
        self.assertTrue(TestCodeGen.test(input,expect,541))
    def test_return_1(self):
        input = """ 
            string foo(){
                return "true";
            }
            void main(){
                putString(foo());
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,542))
    
    def test_return_2(self):
        input = """ 
            int foo(){
                return 10;
            }

            void main(){
                int x;
                x=foo();
                putInt(x);
            }
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input,expect,543))

    def test_return_3(self):
        input = """ 
            int foo1(){
                return 10;
            }

            void foo(){
                putInt(20);
                return;
            }

            void main(){
                foo();
            }
        """
        expect = "20"
        self.assertTrue(TestCodeGen.test(input,expect,544))
    def test_assign_stmt_1(self):
        input = """
            void main(){
                int a,b,c;
                a=b=c=1;
                putInt(a);
            }
        """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input,expect,545))
    def test_assign_stmt_2(self):
        input = """
           void main(){
                int a,b,c;
                c=1;
                a=b=c+1;
                putInt(b);
            }
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,546))
    def test_array_cell_1(self):
        input = """
            void main(){
                int a[1];
                a[0]=9999;
                putInt(a[0]);
            }
        """
        expect = "9999"
        self.assertTrue(TestCodeGen.test(input,expect,547))

    def test_array_cell_2(self):
        input = """
        int a[10];
           void main(){
                float b;
                a[1]=100;
                b=a[1];
                putFloat(b);
            }
        """
        expect = "100.0"
        self.assertTrue(TestCodeGen.test(input,expect,548))
    def test_call_Expression_1(self):
        input = """
            
            void main()
            {
                int a;
                float b;
                a=1;
                b=2.1;
                putInt(foo(a,b)); 
            }
            int foo(int a,float y)
            { 
                return a;
            }
                   
        """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input,expect,549))
    def test_short_circuit_evalution_boolean(self):
        input = """
            void main(){
                putBoolLn(false && true && false);
            }
        """
        expect = """false\n"""
        self.assertTrue(TestCodeGen.test(input,expect,550))
    def test_short_circuit_evalution_in_if(self):
        input = """
            void main(){
                 int a;
                 if (true || false)
                 {
                     a=10;
                     putInt(10);
                 }
             }
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input,expect,551))
    def test_and_or__(self):
        input = """
            void main()
            {
                putBoolLn(true || true);
                putBoolLn(true && false);
                putBoolLn(false && true);
                putBoolLn(false && false);
                putBoolLn(true || true);
                putBoolLn(true && false);
            }
                
        """
        expect = "true\nfalse\nfalse\nfalse\ntrue\nfalse\n"
        self.assertTrue(TestCodeGen.test(input,expect,552))
    def test_array_decla_in_global(self):
        input = """
            int a[10];
           void main(){
               int i;
               for (i=0;i<9;i=i+1)
               {
                   putInt(a[i]);
               }
           }
        """
        expect = "000000000"
        self.assertTrue(TestCodeGen.test(input,expect,553))
    def test_array_decla_in_local(self):
        input = """
            
           void main(){
               int a[10];
               int i;
               for (i=0;i<9;i=i+1)
               {
                   putInt(a[i]);
               }
           }
        """
        expect = "000000000"
        self.assertTrue(TestCodeGen.test(input,expect,554))
    def test_unary__op_advanced_boolean(self):
        input = """
            void main()
            {
             
                putBool(!true);
                putBool(!(5/2==5));
            }
        """
        expect = "falsetrue"
        self.assertTrue(TestCodeGen.test(input,expect,555))
    def test_unary_op_float(self):
        input = """
            void main()
            {
                putFloat(-16-98);
                putFloat(-1213.2121);
            }
        """
        expect = "-114.0-1213.2122"
        self.assertTrue(TestCodeGen.test(input,expect,556))
    def test_unary_op_complex(self):
        input = """
            void main()
            {
                if (!false) {
                    int a;
                    a=10;
                    do{
                        a=a-1;
                        putInt(a);
                    } while(a>0);
                }
            }
        """
        expect = "9876543210"
        self.assertTrue(TestCodeGen.test(input,expect,557))
    def test_and_or_short_circuit_complex_or(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1<2)  || (2<3) &&  (0/0 == 1);
                putBool(c);
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,558))
    def test_and_or_short_circuit_complex_and(self):
        input = """
            int a; 
             float b;
             boolean c;
             int d[5];
             string s;
             void main(){
                 c = (1<2) && (2>3) && (0/0 == 1);
                 putBool(c);
             }
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input,expect,559))
    def test_and_or_short_circuit_complex_or_or(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                c = (1>2) || (2<3) || (0/0 == 1);
                putBool(c);
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,560))
    def test_and_or_short_circuit_complex_and_and(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1<2) && (2<3) && (3<4) && (4>5);
                putBool(c);
            }
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input,expect,561))
    def test_for_complex_1(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum = 0;
                for (a=1;a<=10;a=a+1)
                    sum = sum + a;
                putInt(sum);
            
            }
        """
        expect = "55"
        self.assertTrue(TestCodeGen.test(input,expect,562))
    def test_for_complex_2(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum = 0;
                for (a=1;a<=100;a=a*2)
                    sum = sum + a;
                    putInt(sum);
            }
        """
        expect = "127"
        self.assertTrue(TestCodeGen.test(input,expect,563))
    def test_for_complex_3(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum= 1000;
                for (a=1;a<=10;a=a+1)
                {
                    continue;
                    sum= sum + a;
                }
                putInt(a+sum);
            }
        """
        expect = "1011"
        self.assertTrue(TestCodeGen.test(input,expect,564))
    def test_for_complex_4(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum= 1000;
                for (a=1;a<=10;a=a+1)
                {
                    break;
                    sum= sum + a;
                }
                putInt(a+sum);
            }
        """
        expect = "1001"
        self.assertTrue(TestCodeGen.test(input,expect,565))
    def test_for_complex_5(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum,i,j;
                sum = 0;
                for (i=1;i<=10;i=i+1)
                    for (j=1;j<=i;j=j+1)
                        sum = sum + i*10+j;
                putInt(sum);
            }
        """
        expect = "4070"
        self.assertTrue(TestCodeGen.test(input,expect,566))
    def test_for_complex_6(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum,i,j;
                sum = 20;
                for (i=1;i<=sum;i=i+1)
                    sum = sum -i;
                putInt(sum);        
            }
        """
        expect = "5"
        self.assertTrue(TestCodeGen.test(input,expect,567))
    def test_for_complex_7(self):
        input = """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum,i,j;
                sum = 20;
                for (i=1;i<=sum;i=i+1)
                    i=i+1;
                putInt(i);   
            }
        """
        expect = "21"
        self.assertTrue(TestCodeGen.test(input,expect,568))
    def test_multi_array(self):
        input = """
        float fNum;
        void main()
        {
            int arr[4];
            int a,b;
            b = 10;
            a = b;
            arr[1] = a;
            b = a;
            arr[1] = b;
            arr[2] = arr[1];
            arr[1] = 18;
            a = arr[1];
            arr[3] = a;
            putIntLn(arr[3]);
        }        
        """
        expect = "18\n"
        self.assertTrue(TestCodeGen.test(input,expect,569))
    def test_multi_array_1(self):
        input = """
        float fNum;
        void main()
        {
            int arr[4];
            int a,b;
            float f;
            b = 10;
            a = b;
            fNum = a;
            arr[2] = a;
            f = arr[1];
            b = a;
            arr[2] = b;
            arr[3] = arr[2];
            fNum = arr[3];
            putFloat(fNum);
        }
        """
        expect = "10.0"
        self.assertTrue(TestCodeGen.test(input,expect,570))
    def test_complex_coercion(self):
        input = """
        int  a, b;
        int gArr[4];
        void main()
        {
            int arr[4];
            int c, d;
        
            a = 1;
            b = a = 1;
            c = a;
            b = a = c = b;
            putInt(b);
        
        }
        
        """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input,expect,571))
    def test_multi_arraycell(self):
        input = """
        int  a, b, c;
         int  arr[4];
        void main()
        {
            int iNum, i, j;
        
            arr[1] = 0;
            arr[2] = 1;
            arr[3] = 2;
            a = 3;
            b = a + 2;
            c = b + a + 3;
            iNum = arr[1] + c + (arr[2] - b) - (arr[3] - arr[1]);
            i = iNum - arr[1] + arr[2] - arr[3] - c;
            j = iNum - i + 11;
            putIntLn(j);
        
        }
        
        """
        expect = "23\n"
        self.assertTrue(TestCodeGen.test(input,expect,572))
    def test_multi_arraycell_1(self):
        input = """
        int a,b,c;
            int arr[3];
            float fa,fb,fc;
            int frr[4];
        void main()
        {
            float fNum;
        
            arr[1] = 3;
            a = 3;
            b = a + 2;
            c = b + a + 3;
            fNum = a + b + arr[1] - 1;
            
            putFloat(10);
        
        }
        
        """
        expect = "10.0"
        self.assertTrue(TestCodeGen.test(input,expect,573))
    def test_multi_arraycell_mul(self):
        input = """
        int a,b,c;
            int arr[10];
            float fa,fb,fc;
            int frr[5];
        void main()
        {
            float fNum;
        
            arr[1]= 3;
            a = 3 * 5;
            b = a/ 2;
            c = b + a * 3;
            fNum = a + b / arr[1] + arr[1]*4;
            fa = fNum / arr[1] + c * arr[1];
            fb = fa + a * arr[2] + a / arr[1];
            fc = fb + b * arr[3]+ fNum * a + fNum / (arr[1] + a);
            
            frr[2] = frr[1] + a * b / c;
            putFloatLn(frr[2]);
        
        }
        
        """
        expect = "2.0\n"
        self.assertTrue(TestCodeGen.test(input,expect,574))
    def test_arraycell_boolean_false(self):
        input = """
        int arr[4];
        void main()
        {
            int a, b;
            boolean isTrue;
        
            a= 10;
            b = 11;
            isTrue = a > b ;
            putBool(isTrue);
        
        }
        
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input,expect,575))
    def test_arraycell_boolean_true(self):
        input = """
        float arr[4];
        void main()
        {
            int a;
            int  b;
           boolean isTrue;
            a = 11;
            b = 11;
            isTrue = a <= b ;
            putBool(isTrue);
        }
        
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,576))
    def test_return_stmt_complex(self):
        input = """
        void main()
        {
            float a;
        
            a = ax(2);
            putFloat(a);
          
        }
        
        
        float ax(int a)
        {
            int a;
            a=3;
            if (a==2)
                return 1.2;
            else 
                return 2.0;
        
        }
        
        """
        expect = "2.0"
        self.assertTrue(TestCodeGen.test(input,expect,577))
    def test_if_no_else_stmt_in_if_else_stmt(self):
        input = """
        void main()
        {
            int a;
        
            a = 2;
            if (a > 5) 
                if (a/2==0 )
                    a = a * 2;
            else
            {
                a = 11;
                if (a % 3 != 0) 
                    a = a * 3;
            
            } 
            
            putInt(a);
        
        }
        
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,578))
    def test_dowhile_stmt_complex_continue_stmt(self):
        input = """
        void main()
        {
            int a, iSum;
        
            a = 0;
            iSum = 0;
            do
            {
                a = a + 1;
                if (a % 2==0) 
                    continue;
                iSum = iSum + a;
            }while(a < 20);
            
            putInt(iSum);
        
        }
        
        """
        expect = "100"
        self.assertTrue(TestCodeGen.test(input,expect,579))
    def test_dowhile_stmt_complex_break_stmt(self):
        input = """
        void main()
        {
            int a, iSum;
        
            a = 0;
            iSum = 0;
            do
            {
                a = a + 1;
                if (a > 17)  break;
                if (a % 2==0)  continue;
                iSum = iSum + a;
            }
            while (a < 20 );
            putInt(iSum);
        
        }
        
        """
        expect = "81"
        self.assertTrue(TestCodeGen.test(input,expect,580))
    def test_dowhile_stmt_in_dowhile_stmt(self):
        input = """
        void main()
        {
            int a, b, iSum;
        
            a = b = iSum = 0;
            do
            {
                b = 0;
                a = a + 1;
                do
                {
                    b = b + 1;
                    iSum = iSum + b;
                }
                while (b < a); 
                iSum = iSum + a;
            }
            while (a < 20 );
            putInt(iSum);
        
        }
        
        """
        expect = "1750"
        self.assertTrue(TestCodeGen.test(input,expect,581))
    def test_dowhile_stmt_in_dowhile_stmt_complex(self):
        input = """
        void main()
        {
            int a, b, iSum;
        
            a = b = iSum = 0;
            do
            {
                b = 0;
                a = a + 1;
                do
                {
                    b = b + 1;
                    if (b > 10)  break;
                    if (b % 2==1)  continue;
                    iSum = iSum + b;
                }
                while (b < a );
                if (a % b ==0)  continue;
                if (a + b > 40)  break;
                iSum = iSum + a;
            }
            while (a < 20); 
            putInt(iSum);
        
        }
        
        """
        expect = "554"
        self.assertTrue(TestCodeGen.test(input,expect,582))
    def test_for_stmt_in_for_stmt(self):
        input = """void main()
        {
            int a, b, iSum;
        
            iSum = 0;
            for (a=0;a<10;a=a+1)
            {
                for (b=0;b<=a-1;b=b+1)
                {
                    if (a + b > 17)  break;
                    if (b % 2==0)  continue;
                    iSum = iSum + b;
                }
                
                    
                
                if (iSum > 27)  break;
                if (a % 3 != 0)  continue;
                iSum = iSum + a;
            }
            
                
            
            putInt(iSum);
        
        }
        
        """
        expect = "37"
        self.assertTrue(TestCodeGen.test(input,expect,583))
    def test_block_in_block(self):
        input = """
        int i, j;
        void main()
        {
            int a, b, iSum;
        
            i = 10;
            {
                float i;
                i = 14.3;
                {
                    int i;
                    i = 19;
                    putInt(i);
                }
                
                putFloat(i);
            }
            
            putInt(i);
        
        }
        
        """
        expect = "1914.310" 
        self.assertTrue(TestCodeGen.test(input,expect,584))
    def test_block_in_block_main(self):
        input = """
        int i, j;
        void main()
        {
            int a, b, iSum;
        
            i = 10;
            {
                float i;
                i = 11.8;
                putFloat(i);
            }
            
            i = 11;
        }
        
        """
        expect = "11.8"
        self.assertTrue(TestCodeGen.test(input,expect,585))
    def test_block_in_block_main1(self):
        input = """
        int i, j;
        void main()
        {
            int a, b, iSum;
        
            i = 10;
            {
                float i;
                i = 11.8;
                putFloat(i);
            }
            
            i = 11;
            putInt(i);
        
        }
        
        """
        expect = "11.811"
        self.assertTrue(TestCodeGen.test(input,expect,586))
    def test_return_simple_in_function(self):
        input = """
        void main()
        {
            foo(1.2,1.5);
        }
        void foo(float a,float b)
        {
            putFloat(a+b);
        }
        """
        expect = "2.7"
        self.assertTrue(TestCodeGen.test(input,expect,587))
    def test_return_complex_int_float(self):
        input = """
        void main()
        {
            foo(1,1.5,10,10+1);
        }
        void foo(int a,float b,int c,int d)
        {
            putFloat(a+b);
        }
        """
        expect = "2.5"
        self.assertTrue(TestCodeGen.test(input,expect,588))
    def test_return_complex_int(self):
        input = """
        void main()
        {
            int x;
            x=foo(1,1.5,10,10+1);
            putInt(x);
        }
        int foo(int a,float b,int c,int d)
        {
            return 99;
        }
        """
        expect = "99"
        self.assertTrue(TestCodeGen.test(input,expect,589))
    def test_return_complex_int_float_in_function(self):
        input = """
        void main()
        {
            putFloat(foo(1,1.5,10,10+1));
        }
        float foo(int a,float b,int c,int d)
        {
            return a+b+c+d;
        }
        """
        expect = "23.5"
        self.assertTrue(TestCodeGen.test(input,expect,590))
    def test_return_in_if(self):
        input = """
        void main()
        {
            putFloat(foo(1,true));
        }
        float foo(int a,boolean b)
        {
            if (b){
                return 1.2;
            } else{
                return 2.1;
            }
        }
        """
        expect = "1.2"
        self.assertTrue(TestCodeGen.test(input,expect,591))
    def test_multi_block(self):
        input = """
        void main()
        {
            {
                {
                    {
                        putInt(99);
                    }
                }
            }
        }
        
        """
        expect = "99"
        self.assertTrue(TestCodeGen.test(input,expect,592))
    def test_if_multi_block(self):
        input = """
        void main()
        {
            int a;
            float b;
            {
                {
                    a=10;
                    b=20;
                    {
                        if (b>a)
                        {
                            putInt(a);
                        }
                    }
                }
            }
        }
        
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input,expect,593))
    def test_for_if_multi_block(self):
        input = """
        void main()
        {
            int a;
            int i;
            {
                {
                    a=10;
                   
                    {
                        for (i=0;i<20;i=i+1)
                        {
                            if (i>a)
                            {
                                putInt(i);
                            }
                        }
                        
                    }
                }
            }
        }
        
        """
        expect = "111213141516171819"
        self.assertTrue(TestCodeGen.test(input,expect,594))
    def test_for_continue_multi_block(self):
        input = """
        void main()
        {
            int a;
            {
                int i;
                a=10;
                {
                    for (i=0;i<20;i=i+1)
                        {
                            if (i>a)
                            {
                                continue;
                                putInt(i);
                            }
                        }
                }
            }
        }
        
        """
        expect = ""
        self.assertTrue(TestCodeGen.test(input,expect,595))
    def test_for_if_break_multi_block(self):
        input = """
        void main()
        {
            
            int b;
            {
                {
                   int i;
                    b=10;
                    {
                        for (i=0;i<20;i=i+1)
                        {
                            if (i>b)
                            {
                                break;
                                putInt(i);
                            }
                        }
                    }
                }
            }
        }
        
        """
        expect = ""
        self.assertTrue(TestCodeGen.test(input,expect,596))
    def test_if_binary_or_boolean(self):
        input = """
        void main()
        {

            if (true)
            {
                putBool((2 * 3 <=  5) || (1 < 6 ) );
            }
        }
        
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(input,expect,597))
    def test_if_binary_and_boolean(self):
        input = """
        void main()
        {

            if (true)
            {
                putBool((2 * 3 <=  5) && (1 < 6 ) );
            }
        }
        
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(input,expect,598))
    def test_final_complex(self):
        input = """
        void main()
        {
            int a;
            int i;
            {
                {
                    a=10;
                    {
                        
                        for (i=0;i<20;i=i+2)
                        {
                            if (i>a)
                            {
                                putBool((2 * 3 <=  5) && (1 < 6 ) );
                                putInt(i);
                            }
                        }
                    }
                }
            }
        }
        
        """
        expect = "false12false14false16false18"
        self.assertTrue(TestCodeGen.test(input,expect,599))
      



    
    

