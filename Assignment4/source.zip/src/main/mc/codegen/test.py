import unittest
from TestUtils import TestCodeGen
from AST import *


class CheckCodeGenSuite(unittest.TestCase):
    def test_int_literal(self):
        input = """
            void main()
            {
                putFloat(1.5);
            }
                
            
        """
        expect = "1.5"
        self.assertTrue(TestCodeGen.test(input,expect,500))
    
    def test_print_int(self):
        code = \
        """
            void main()
            {
                putInt(20);
            }
                
            
        """
        expect = "20"
        self.assertTrue(TestCodeGen.test(code,expect,501))

    def test_print_boolean(self):
        code = \
        """
            void main()
            {
                putBool(true);
                putBool(false);
            }
                
            
        """
        expect = "truefalse"
        self.assertTrue(TestCodeGen.test(code,expect,502))

    def test_print_string(self):
        code = \
        """
            void main(){
                putString("hello world");
            }
            
                
            
        """
        expect = "hello world"
        self.assertTrue(TestCodeGen.test(code,expect,503))

    def test_assign_1(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                a=1;
                putInt(a);
            }
           
        """
        expect = "1"
        self.assertTrue(TestCodeGen.test(code,expect,504))


    def test_assign_2(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                b=2;
                putFloat(b);
            }
            
        """
        expect = "2.0"
        self.assertTrue(TestCodeGen.test(code,expect,505))

    def test_assign_3(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                d[0]=10;
                putInt(d[0]);
            }
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(code,expect,506))

    def test_assign_4(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                c=true;
                putBool(c);
                c=false;
                putBool(c);
            }
        
        """
        expect = "truefalse"
        self.assertTrue(TestCodeGen.test(code,expect,507))

    def test_binop_1(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                a = 1+2*3-4;
                putInt(a);
            }
            
        """
        expect = "3"
        self.assertTrue(TestCodeGen.test(code,expect,508))

    def test_binop_2(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                a = 100 % 7;
                putInt(a);
            }
            
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(code,expect,509))

    def test_binop_3(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                b = 100/4/5;
                putFloat(b);
            }
            
                
            
        """
        expect = "5.0"
        self.assertTrue(TestCodeGen.test(code,expect,510))


    def test_binop_4(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                b = 1.2*3/2+4.5-2;
                putFloat(b);
            }
            
                
            
        """
        expect = "4.3"
        self.assertTrue(TestCodeGen.test(code,expect,511))

    def test_binop_5(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                b = 10-5*20 / 3/11;
                putFloat(b);
            }
            
                
            
        """
        expect = "7.0"
        self.assertTrue(TestCodeGen.test(code,expect,512))

    def test_binop_6(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = 1>2;
                putBool(c);
                c = 1>=2;
                putBool(c);
                c = 1<2;
                putBool(c);
                c = 1<=2;
                putBool(c);
                c = 1==2;
                putBool(c);
                c = 1!=2;
                putBool(c);
            }
            
                
            
        """
        expect = "falsefalsetruetruefalsetrue"
        self.assertTrue(TestCodeGen.test(code,expect,513))

    def test_binop_7(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1>2) && (1<2) || (1==1);
                putBool(c);
            }
            
                
            
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(code,expect,514))

    def test_and_or_short_circuit_1(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1>2) && (0/0 == 1);
                putBool(c);
            }
            
                
            
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(code,expect,515))

    def test_and_or_short_circuit_2(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                c = (1<2) || (0/0 == 1);
                putBool(c);
            }
            
                
            
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(code,expect,516))

    def test_and_or_short_circuit_3(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                c = (1<2) && (2>3) && (0/0 == 1);
                putBool(c);
            }
            
                
            
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(code,expect,517))

    def test_and_or_short_circuit_4(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main(){
                c = (1>2) || (2<3) || (0/0 == 1);
                putBool(c);
            }
            
                
            
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(code,expect,518))

    def test_and_or_short_circuit_5(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1<2) && (2<3) && (3<4) && (4>5);
                putBool(c);
            }
            
                
            
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(code,expect,515))

    def test_and_or_short_circuit_6(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1>2) || (2>3) && (0/0 == 1);
                putBool(c);
            }
            
                
            
        """
        expect = "false"
        self.assertTrue(TestCodeGen.test(code,expect,516))

    def ttest_and_or_short_circuit_7(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                c = (1<2)  || (2<3) &&  (0/0 == 1);
                putBool(c);
            }
            
                
            
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(code,expect,517))

    def test_for_loop_1(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum = 0;
                for (a=1;a<=10;a=a+1)
                    sum = sum + a;
                putInt(sum);
            
            }
            
        """
        expect = "55"
        self.assertTrue(TestCodeGen.test(code,expect,518))

    def test_for_loop_2(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum = 0;
                for (a=1;a<=100;a=a*2)
                    sum = sum + a;
                    putInt(sum);
            }
            
        """
        expect = "127"
        self.assertTrue(TestCodeGen.test(code,expect,519))

    def test_for_loop_3(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum= 1000;
                for (a=1;a<=10;a=a+1)
                {
                    break;
                    sum= sum + a;
                }
               
                
                putInt(a+sum);

            
            }
            
        """
        expect = "1001"
        self.assertTrue(TestCodeGen.test(code,expect,520))

    def test_for_loop_4(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum;
            
                sum= 1000;
                for (a=1;a<=10;a=a+1)
                {
                    continue;
                    sum= sum + a;
                }
               
                
                putInt(a+sum);

            
            }
        """
        expect = "1011"
        self.assertTrue(TestCodeGen.test(code,expect,521))

    def test_for_loop_5(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum,i,j;
                sum = 0;
                for (i=1;i<=10;i=i+1)
                    for (j=1;j<=i;j=j+1)
                        sum = sum + i*10+j;
                putInt(sum);
            }
           
            
                
            
        """
        expect = "4070"
        self.assertTrue(TestCodeGen.test(code,expect,522))

    def test_for_loop_6(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum,i,j;
                sum = 20;
                for (i=1;i<=sum;i=i+1)
                    sum = sum -i;
                putInt(sum);        
            }
            
        """
        expect = "5"
        self.assertTrue(TestCodeGen.test(code,expect,523))


    def test_for_loop_7(self):
        code = \
        """
            int a; 
            float b;
            boolean c;
            int d[5];
            string s;
            void main()
            {
                int sum,i,j;
                sum = 20;
                for (i=1;i<=sum;i=i+1)
                    i=i+1;
                putInt(i);   
            }
            
        """
        expect = "21"
        self.assertTrue(TestCodeGen.test(code,expect,524))
    def test_global_variable(self):
        """Program => Test global variable and function whose return type is voidtype."""
        input = """
        
        int a;
        float b;
        float frr[4];
        int arr[5];
        void main(){
            putInt(10);
        }
        void pvoid()
        {

        }
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input,expect,525))
    def test_manipulate_data_1(self):
        """Program => manipulate data in Main function: Assign recur many times: Arraytype and primitiveType"""
        input = """
        float fNum;
        void main()
        {
            int arr[4];
            int a,b;
            b = 10;
            a = b;
            arr[1] = a;
            b = a;
            arr[1] = b;
            arr[2] = arr[1];
            arr[1] = 18;
            a = arr[1];
            arr[3] = a;
            putIntLn(arr[3]);
        }
        
            
        
        """
        expect = "18\n"
        self.assertTrue(TestCodeGen.test(input,expect,526))
    def test_manipulate_data_2(self):
        """Program => manipulate data in Main function: Assign recur many times: It's has coercion!"""
        input = """
        
        float fNum;
        void main()
        {
            int arr[4];
            int a,b;
            float f;
            b = 10;
            a = b;
            fNum = a;
            arr[2] = a;
            f = arr[1];
            b = a;
            arr[2] = b;
            arr[3] = arr[2];
            fNum = arr[3];
            putFloatLn(fNum);
        }
        """
        expect = "10.0\n"
        self.assertTrue(TestCodeGen.test(input,expect,527))
    def test_manipulate_data_3(self):
        """Program => manipulate data in Main function: Assign recur many times: It's has complex coercion!"""
        input = """
        int  a, b;
        int gArr[4];
        void main()
        {
            int arr[4];
            int c, d;
        
            a = 1;
            b = a = 1;
            c = a;
            b = a = c = b;
            putIntLn(b);
        
        }
        
        """
        expect = "1\n"
        self.assertTrue(TestCodeGen.test(input,expect,528))
    def test_manipulate_data_4(self):
        """Program => manipulate data in Main function: Expression : Operator are add, minus; operand are array cell, literal in"""
        input = """
        int  a, b, c;
         int  arr[4];
        void main()
        {
            int iNum, i, j;
        
            arr[1] = 0;
            arr[2] = 1;
            arr[3] = 2;
            a = 3;
            b = a + 2;
            c = b + a + 3;
            iNum = arr[1] + c + (arr[2] - b) - (arr[3] - arr[1]);
            i = iNum - arr[1] + arr[2] - arr[3] - c;
            j = iNum - i + 11;
            putIntLn(j);
        
        }
        
        """
        expect = "23\n"
        self.assertTrue(TestCodeGen.test(input,expect,529))
    def test_manipulate_data_5(self):
        """Program => manipulate data in Main function: Expression : Operator are add, minus; operand are array cell, literal :float and int"""
        input = """
        int a,b,c;
            int arr[3];
            float fa,fb,fc;
            int frr[4];
        void main()
        {
            float fNum;
        
            arr[1] = 3;
            a = 3;
            b = a + 2;
            c = b + a + 3;
            fNum = a + b + arr[1] - 1;
            
            putFloatLn(10);
        
        }
        
        """
        expect = "10.0\n"
        self.assertTrue(TestCodeGen.test(input,expect,530))
    def test_manipulate_data_6(self):
        """Program => manipulate data in Main function: Expression : Operator are add, minus, mul; operand are array cell, literal :float and int"""
        input = """
        int a,b,c;
            int arr[10];
            float fa,fb,fc;
            int frr[5];
        void main()
        {
            float fNum;
        
            arr[1] = 3;
            a = 3*5;
            b = a + 2;
            c = b + a * 3;
            fNum = a + b + arr[1] * 4;
            fa = fNum + c * arr[1];
            fb = fa + a * arr[2];
            fc = fb + b * arr[3]+ fNum * a;
            
            frr[2] = frr[1] + a * b * c;
            putFloatLn(10);
        
        }
        
        """
        expect = "10.0\n"
        self.assertTrue(TestCodeGen.test(input,expect,531))
    def test_manipulate_data_7(self):
        """Program => manipulate data in Main function: Expression : Operator are add, minus, mul, div; operand are array cell, literal :float and int"""
        input = """
        int a,b,c;
            int arr[10];
            float fa,fb,fc;
            int frr[5];
        void main()
        {
            float fNum;
        
            arr[1]= 3;
            a = 3 * 5;
            b = a/ 2;
            c = b + a * 3;
            fNum = a + b / arr[1] + arr[1]*4;
            fa = fNum / arr[1] + c * arr[1];
            fb = fa + a * arr[2] + a / arr[1];
            fc = fb + b * arr[3]+ fNum * a + fNum / (arr[1] + a);
            
            frr[2] = frr[1] + a * b / c;
            putFloatLn(frr[2]);
        
        }
        
        """
        expect = "2.0\n"
        self.assertTrue(TestCodeGen.test(input,expect,532))
    def test_manipulate_data_8(self):
        """Program => manipulate data in Main function: UniryOp : Operator is Minus; operand is FloatLiteral"""
        input = """
        float arr[4];
        void main()
        {
            float fNum, i, j;
        
            arr[1] = 11.5;
            arr[3] = 8.5;
            i = -arr[1] + -arr[2];
            j = -arr[3]*3;
            fNum = i + j;
            putFloatLn(2);
        
        }
        
        """
        expect = "2.0\n"
        self.assertTrue(TestCodeGen.test(input,expect,533))
    def test_manipulate_data_9(self):
        """Program => manipulate data in Main function: Operator are > ; operand is IntLiteral"""
        input = """
        int arr[4];
        void main()
        {
            int a, b;
            boolean isTrue;
        
            a= 10;
            b = 11;
            isTrue = a > b ;
            putBoolLn(isTrue);
        
        }
        
        """
        expect = "false\n"
        self.assertTrue(TestCodeGen.test(input,expect,534))
    def test_manipulate_data_10(self):
        """Program => manipulate data in Main function: Operator are <= ; operand is FloatLiteral"""
        input = """
        float arr[4];
        void main()
        {
            int a;
            int  b;
           boolean isTrue;
            a = 11;
            b = 11;
            isTrue = a <= b ;
            putBoolLn(isTrue);
        }
        
        """
        expect = "true\n"
        self.assertTrue(TestCodeGen.test(input,expect,535))
    def test_manipulate_data_11(self):
        """Program => manipulate data in Main function: Operator are > ; operand is IntLiteral"""
        input = """
        int arr[4];
        void main()
        {
            int a[4]; 
            int b;
            boolean isTrue;
    
            arr[1] = 11;
            arr[2] = arr[1] + 2;
            isTrue = arr[2] > 12 ;
            putBoolLn(isTrue);
        
        }
        
        """
        expect = "true\n"
        self.assertTrue(TestCodeGen.test(input,expect,536))
    def test_if_no_else_stmt(self):
        """Program => manipulate data in Main function: if no else stmt"""
        input = """
        void main()
        {
            int a;
        
            a = 1;
            if (a > 1)
                a = 10;
            putIntLn(a);
        
        }
        
        """
        expect = "1\n"
        self.assertTrue(TestCodeGen.test(input,expect,537))
    def test_return_stmt(self):
        """Program => manipulate data in Main function: return stmt"""
        input = """
        void main()
        {
            float a;
        
            a = ax(2);
            putFloat(a);
          
        }
        
        
        float ax(int a)
        {
            int a;
            a=3;
            if (a==2)
                return 1.2;
            else 
                return 2.0;
        
        }
        
        """
        expect = "2.0"
        self.assertTrue(TestCodeGen.test(input,expect,538))
    def test_return_void_stmt(self):
        """Program => manipulate data in Main function: return void stmt"""
        input = """
        void main()
        {
            foo(10);
        }
        
        void foo(int a)
        {
            a=5;
        }
            
        
        """
        expect = ""
        self.assertTrue(TestCodeGen.test(input,expect,539))
    def test_return_void_stmt_and_print_Int(self):
        """Program => manipulate data in Main function:another return void stmt and print Int"""
        input = """
        void main()
        {
            int a;
        
            a = 1;
            test(a);
        
        }
        
        
        void test( int a)
        {
            
            putInt(a);
        
        }
        
        """
        expect = "1"
        self.assertTrue(TestCodeGen.test(input,expect,540))
    def test_if_else_stmt_simple_enter_thenStmt(self):
        """Program => manipulate data in Main function: if-else stmt simple!(enter thenStmt)"""
        input = """
        void main()
        {
            int a;
        
            a = 2;
            if (a > 1)
                a = 10;
            else a = 11;
            putInt(a);
        
        }
        
        """
        expect = "10"
        self.assertTrue(TestCodeGen.test(input,expect,541))
    def test_if_else_stmt_simple_enter_elseStmt(self):
        """Program => manipulate data in Main function: if-else stmt simple!(enter elseStmt)"""
        input = """
        void main()
        {
            int a;
        
            a = 2;
            if (a > 10)
                a = 10;
            else a = 11;
            putInt(a);
        
        }
        """
        expect = "11"
        self.assertTrue(TestCodeGen.test(input,expect,542))
    def test_if_no_else_stmt_inner_if_else_stmt(self):
        """Program => manipulate data in Main function: if no else stmt inner if-else stmt"""
        input = """
        void main()
        {
            int a;
        
            a = 2;
            if (a > 5) 
                if (a/2==0 )
                    a = a * 2;
            else
            {
                a = 11;
                if (a % 3 != 0) 
                    a = a * 3;
            
            } 
            
            putInt(a);
        
        }
        
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,543))
    def test_if_else_stmt_inner_if_else_stmt(self):
        """Program => manipulate data in Main function: if-else stmt inner if-else stmt"""
        input = """
        void main()
        {
            int a;
        
            a = 2;
            if (a > 5) 
                if (a % 2==0) 
                    a = a * 2;
            else 
            {

            
                a = 11;
                if (a % 3 != 0) 
                    a = a * 3 / 2;
            }
            putInt(a);
        
        }
        
        """
        expect = "2"
        self.assertTrue(TestCodeGen.test(input,expect,544))
    def test_dowhile_stmt_simple(self):
        """Program => manipulate data in Main function: dowhile stmt simple!"""
        input = """
        void main()
        {
            int a;
        
            a = 1;
            do
            {
                putInt(a);
                a = a + 1;
                
            }
            while (a < 5) ;
        }
        """
        expect = "1234"
        self.assertTrue(TestCodeGen.test(input,expect,545))
    def test_dowhile_stmt_simple_It_has_continue_stmt(self):
        """Program => manipulate data in Main function: dowhile stmt simple - It has continue stmt!"""
        input = """
        void main()
        {
            int a, iSum;
        
            a = 0;
            iSum = 0;
            do
            {
                a = a + 1;
                if (a % 2==0) 
                    continue;
                iSum = iSum + a;
            }while(a < 20);
            
            putInt(iSum);
        
        }
        
        """
        expect = "100"
        self.assertTrue(TestCodeGen.test(input,expect,546))
    def test_dowhile_stmt_simple_It_has_break_stmt(self):
        """Program => manipulate data in Main function: dowhile stmt simple - It has break stmt!"""
        input = """
        void main()
        {
            int a, iSum;
        
            a = 0;
            iSum = 0;
            do
            {
                a = a + 1;
                if (a > 17) break;
                iSum = iSum + a;
            }
            while (a < 20); 
            putInt(iSum);
        
        }
        
        """
        expect = "153"
        self.assertTrue(TestCodeGen.test(input,expect,547))
    def test_dowhile_stmt_simple_It_have_continue_stmt_and_break_stmt(self):
        """Program => manipulate data in Main function: dowhile stmt simple - It have continue stmt & break stmt!"""
        input = """
        void main()
        {
            int a, iSum;
        
            a = 0;
            iSum = 0;
            do
            {
                a = a + 1;
                if (a > 17)  break;
                if (a % 2==0)  continue;
                iSum = iSum + a;
            }
            while (a < 20 );
            putInt(iSum);
        
        }
        
        """
        expect = "81"
        self.assertTrue(TestCodeGen.test(input,expect,548))
    def test_dowhile_stmt_inner_dowhile_stmt(self):
        """Program => manipulate data in Main function: dowhile stmt inner dowhile stmt!"""
        input = """
        void main()
        {
            int a, b, iSum;
        
            a = b = iSum = 0;
            do
            {
                b = 0;
                a = a + 1;
                do
                {
                    b = b + 1;
                    iSum = iSum + b;
                }
                while (b < a); 
                iSum = iSum + a;
            }
            while (a < 20 );
            putInt(iSum);
        
        }
        
        """
        expect = "1750"
        self.assertTrue(TestCodeGen.test(input,expect,549))
    def test_dowhile_stmt_inner_dowhile_stmt_complex(self):
        """Program => manipulate data in Main function: dowhile stmt inner dowhile stmt complex: It have break and continue stmt!"""
        input = """
        void main()
        {
            int a, b, iSum;
        
            a = b = iSum = 0;
            do
            {
                b = 0;
                a = a + 1;
                do
                {
                    b = b + 1;
                    if (b > 10)  break;
                    if (b % 2==1)  continue;
                    iSum = iSum + b;
                }
                while (b < a );
                if (a % b ==0)  continue;
                if (a + b > 40)  break;
                iSum = iSum + a;
            }
            while (a < 20); 
            putInt(iSum);
        
        }
        
        """
        expect = "554"
        self.assertTrue(TestCodeGen.test(input,expect,550))
    def test_for_stmt_innner_for_stmt(self):
        """Program => manipulate data in Main function: for stmt innner for stmt: It have continue stmt and break stmt"""
        input = """void main()
        {
            int a, b, iSum;
        
            iSum = 0;
            for (a=0;a<10;a=a+1)
            {
                for (b=0;b<=a-1;b=b+1)
                {
                    if (a + b > 17)  break;
                    if (b % 2==0)  continue;
                    iSum = iSum + b;
                }
                
                    
                
                if (iSum > 27)  break;
                if (a % 3 != 0)  continue;
                iSum = iSum + a;
            }
            
                
            
            putIntLn(iSum);
        
        }
        
        """
        expect = "37\n"
        self.assertTrue(TestCodeGen.test(input,expect,551))
    def test_block_inner_main_block(self):
        """Program => manipulate data in Main function: block inner main block"""
        input = """
        int i, j;
        void main()
        {
            int a, b, iSum;
        
            i = 10;
            {
                float i;
                i = 11.8;
                putFloat(i);
            }
            
            i = 11;
            putIntLn(i);
        
        }
        
        """
        expect = "11.811\n"
        self.assertTrue(TestCodeGen.test(input,expect,552))
    def test_block_inner_block(self):
        """Program => manipulate data in Main function: block inner block"""
        input = """
        int i, j;
        void main()
        {
            int a, b, iSum;
        
            i = 10;
            {
                float i;
                i = 14.3;
                {
                    int i;
                    i = 19;
                    putInt(i);
                }
                
                putFloat(i);
            }
            
            putInt(i);
        
        }
        
        """
        expect = "1914.310" 
        self.assertTrue(TestCodeGen.test(input,expect,553))
    def test_Funcall_in_main_function(self):
        """Program => Funcall is stmt in main function"""
        input = """
        int a;
        void main()
        {
            int b;
            float c;
        
            b = 5;
            c = foo(b);
            putFloat(c);
        
        }
        
        
        int foo(int a)
        {
            return a * a;
        }
        
            
        
        """
        expect = "25.0"
        self.assertTrue(TestCodeGen.test(input,expect,554))
    def test_return_stmt_in_if_else_stmt_in_function_call(self):
        """Program => return stmt in if-else stmt in function call"""
        input = """
        void main()
        {
            int a, b, res;
        
            a = 1;
            b = 1;
            res = foo(a, b);
            putIntLn(res);
        
        }
        
        
        int foo(int a, int b)
        {
            if (a==b)
                return 111;
            else 
                return 222;
        }
        
            
        
        """
        expect = "111\n"
        self.assertTrue(TestCodeGen.test(input,expect,555))
    def test_recurtion(self):
        code = \
        """
            int a[5];
            float b[5];
            void main()
            {
                int i, j, s, c;
            
                putInt(f(7));
            
            }
            

            int f(int n)
            {
                
                if (n<=0)  return 0;
                if (n==0)  return 1;
                if (n==1)  return 1;
                return f(n-1) + f(n-2);
            }
            
        """
        expect = "13"
        self.assertTrue(TestCodeGen.test(code,expect,556))
    def test_unop(self):
        code = \
        """
            
            void main()
            {
               
                putBool(!false);
                
            }
        """
        expect = "true"
        self.assertTrue(TestCodeGen.test(code,expect,557))







    # def test_79(self):
    #     """Program => manipulate data in Main function:another return void stmt and print Int"""
    #     input = """
    #     float x;
    #         void main()
    #         {
    #             int a;
    #             a=-2;
    #             x=a*a;
    #             if (x >= a){
    #                 putInt(x);
    #             }  
    #         }
    #     """
    #     expect = "1"
    #     self.assertTrue(TestCodeGen.test(input,expect,600))

    