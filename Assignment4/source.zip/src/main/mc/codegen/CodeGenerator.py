'''
 *   @author Nguyen Hua Phung
 *   @version 1.0
 *   23/10/2015
 *   This file provides a simple version of code generator
 *
'''
#--------------------MSSV:1710849----------------
from Utils import *
from StaticCheck import *
from StaticError import *
from Emitter import Emitter
from Frame import Frame
from abc import ABC, abstractmethod
from functools import*
class CodeGenerator(Utils):
    def __init__(self):
        self.libName = "io"

    def init(self):
        return [Symbol("getInt", MType(list(), IntType()), CName(self.libName)),
                Symbol("putInt", MType([IntType()],VoidType()), CName(self.libName)),
                Symbol("putIntLn", MType([IntType()],VoidType()), CName(self.libName)),
                Symbol("getFloat", MType([], FloatType()), CName(self.libName)),
                Symbol("putFloat", MType([FloatType()], VoidType()), CName(self.libName)),
                Symbol("putFloatLn", MType([FloatType()], VoidType()), CName(self.libName)),
                Symbol("putBool", MType([BoolType()],VoidType()), CName(self.libName)),
                Symbol("putBoolLn", MType([BoolType()], VoidType()), CName(self.libName)),
                Symbol("putString", MType([StringType()], VoidType()), CName(self.libName)),
                Symbol("putStringLn", MType([StringType()], VoidType()), CName(self.libName)),
                Symbol("putLn", MType(list(), VoidType()), CName(self.libName))]

        return []

    def gen(self, ast, dir_):
        #ast: AST
        #dir_: String

        gl = self.init()
        gc = CodeGenVisitor(ast, gl, dir_)
        gc.visit(ast, None)
    
class ClassType(Type):
    def __init__(self, cname):
        #cname: String
        self.cname = cname

    def __str__(self):
        return "ClassType"

    def accept(self, v, param):
        return v.visitClassType(self, param)

class SubBody():
    def __init__(self, frame, sym):
        #frame: Frame
        #sym: List[Symbol]

        self.frame = frame
        self.sym = sym

class Access():
    def __init__(self, frame, sym, isLeft, isFirst, isDup=False):
        #frame: Frame
        #sym: List[Symbol]
        #isLeft: Boolean
        #isFirst: Boolean

        self.frame = frame
        self.sym = sym
        self.isLeft = isLeft
        self.isFirst = isFirst
        self.isDup = isDup

class Val(ABC):
    pass

class Index(Val):
    def __init__(self, value):
        #value: Int

        self.value = value

class CName(Val):
    def __init__(self, value):
        #value: String

        self.value = value

class CodeGenVisitor(BaseVisitor, Utils):
    def __init__(self, astTree, env, dir_):
        #astTree: AST
        #env: List[Symbol]
        #dir_: File

        self.astTree = astTree
        self.env = env
        self.className = "MCClass"
        self.path = dir_
        self.emit = Emitter(self.path + "/" + self.className + ".j")
        self.currentFunc = Symbol("null", MType([],VoidType()), CName(self.className))

    def varDecl(self,ast,c):
        ctxt=c
        name=ast.variable
        varType=ast.varType

        self.emit.printout(self.emit.emitATTRIBUTE(name,varType,False,""))

        varSymbol=Symbol(name,varType,CName(self.className))

        ctxt.append(varSymbol)
        return ctxt

    def funcDecl(self,ast,c):
        ctxt=c
        name=ast.name.name

        funcType=MType([x.varType for x in ast.param],ast.returnType)

        funcSymbol=Symbol(name,funcType,CName(self.className))

        ctxt.append(funcSymbol)
        return ctxt
    
    def visitProgram(self, ast, c):
        #ast: Program
        #c: Any

        self.emit.printout(self.emit.emitPROLOG(self.className, "java.lang.Object"))

        lstVarDecl=list(filter(lambda x:type(x) is VarDecl,ast.decl))
        lstFuncDecl=list(filter(lambda x:type(x) is FuncDecl,ast.decl))

        for x in ast.decl:
            self.env=self.varDecl(x,self.env) if type(x) is VarDecl else self.funcDecl(x, self.env)
        
        e=SubBody(None,self.env)    

        for x in lstFuncDecl:
            e=self.visit(x,e)

        # generate default constructor
        self.genMETHOD(FuncDecl(Id("<init>"), list(), None, Block(list())), c, Frame("<init>", VoidType))
        lstArrayType=[]
        for x in lstVarDecl:
            if isinstance(x.varType,ArrayType):
                lstArrayType+=[x]
        if lstArrayType:
            self.emit.printout(self.emit.emitCLINIT(self.className, lstArrayType, Frame("<clinit>", VoidType())))
        self.emit.emitEPILOG()
        return c

    def genMETHOD(self, consdecl, o, frame):
        #consdecl: FuncDecl
        #o: Any
        #frame: Frame

        isInit = consdecl.returnType is None
        isMain = consdecl.name.name == "main" and len(consdecl.param) == 0 and type(consdecl.returnType) is VoidType
        returnType = VoidType() if isInit else consdecl.returnType
        methodName = "<init>" if isInit else consdecl.name.name
        intype = [ArrayPointerType(StringType())] if isMain else [x.varType for x in consdecl.param]
        
        mtype = MType(intype, returnType)

        self.emit.printout(self.emit.emitMETHOD(methodName, mtype, not isInit, frame))

        frame.enterScope(True)

        glenv = o

        # Generate code for parameter declarations
        if isInit:
            self.emit.printout(self.emit.emitVAR(frame.getNewIndex(), "this", ClassType(self.className), frame.getStartLabel(), frame.getEndLabel(), frame))
        if isMain:
            self.emit.printout(self.emit.emitVAR(frame.getNewIndex(), "args", ArrayPointerType(StringType()), frame.getStartLabel(), frame.getEndLabel(), frame))
        glSubBody = SubBody(frame, glenv)
        if (isMain is False) and (intype != []):
            for x in consdecl.param:
                glSubBody = self.visit(x, glSubBody)
        lsArrVarDecl=[]
        for x in consdecl.body.member:
            if isinstance(x,VarDecl):
                if isinstance(x.varType,ArrayType):
                    lsArrVarDecl.append(x)
                glSubBody = self.visit(x, glSubBody)
                
        
       
        if lsArrVarDecl!=[]:
            for x in lsArrVarDecl:
                self.arrayTypeDecl(x, glSubBody)

        self.emit.printout(self.emit.emitLABEL(frame.getStartLabel(), frame))

        # Generate code for statements
        if isInit:
            self.emit.printout(self.emit.emitREADVAR("this", ClassType(self.className), 0, frame))
            self.emit.printout(self.emit.emitINVOKESPECIAL(frame))
        

        for x in consdecl.body.member:
            if isinstance(x,Stmt):
                self.visit(x,glSubBody)
        
        returnStmt = list(filter(lambda x:type(x) is Return, consdecl.body.member))
        sizeStack=frame.getStackSize()
        if sizeStack!=0:
            for x in range(sizeStack):
                self.emit.printout(self.emit.emitPOP(frame))
        self.emit.printout(self.emit.emitLABEL(frame.getEndLabel(), frame))
        if type(returnType) is VoidType or not returnStmt:
            self.emit.printout(self.emit.emitRETURN(VoidType(), frame))
        self.emit.printout(self.emit.emitENDMETHOD(frame))
        frame.exitScope();
    def visitFuncDecl(self, ast, c):
        #ast: FuncDecl
        #o: Any
        sym = c.sym
        frame = Frame(ast.name.name, ast.returnType )
        self.curFunc = self.lookup(ast.name.name, sym, lambda x: x.name)
        self.genMETHOD(ast, sym, frame)
        return c
    def arrayTypeDecl(self, ast, c):
        sym = c.sym
        frame = c.frame
        idx = self.lookup(ast.variable, sym, lambda x: x.name)
        idx=idx.value.value
        self.emit.printout(self.emit.emitNEWARRAY(ast.varType,frame))
        self.emit.printout(self.emit.emitWRITEVAR(ast.variable, ast.varType, idx, frame))
        return SubBody(frame, sym)
    def visitVarDecl(self, ast, c):
        env = c.sym if type(c) is SubBody else []
        frame = c.frame
        idx = c.frame.getNewIndex()
        self.emit.printout(self.emit.emitVAR(idx, ast.variable, ast.varType, frame.getStartLabel(), frame.getEndLabel(), frame))
        return SubBody(frame, [Symbol(ast.variable, ast.varType, Index(idx))] + env)
    def visitBlock(self,ast,c):
        frame = c.frame
        nenv = c.sym

        frame.enterScope(False)

        lstVarDecl=list(filter(lambda x:isinstance(x,VarDecl),ast.member))
        varEnv = reduce(lambda x, y: self.visit(y, x), lstVarDecl, SubBody(frame, nenv))
        lstVarArray = list(filter(lambda x: type(x.varType) is ArrayType, lstVarDecl))

       
        self.emit.printout (self.emit.emitLABEL(frame.getStartLabel(),frame))
        list(map(lambda x: self.arrayTypeDecl(x, varEnv), lstVarArray))
        
        for x in ast.member:
            if isinstance(x,Stmt):
                self.visit(x,varEnv)
        self.emit.printout(self.emit.emitLABEL(frame.getEndLabel(), frame))
        frame.exitScope()
        return None
    def genCodeBinExpr(self, frame, leftCode, leftType, rightCode, rightType, reqFloat = False):
        if type(leftType) is FloatType and type(rightType) is IntType:
            return leftCode + rightCode + self.emit.emitI2F(frame), FloatType()
        if type(leftType) is IntType and type(rightType) is FloatType:
            return leftCode + self.emit.emitI2F(frame) + rightCode , FloatType()
        if reqFloat and type(leftType) is IntType:
            return leftCode + self.emit.emitI2F(frame) + rightCode + self.emit.emitI2F(frame), FloatType() 
        return leftCode + rightCode, leftType

    def visitBinaryOp(self, ast, c):
        frame = c.frame
        sym = c.sym
        op = ast.op
        code_I2F=""
        _dup=False
        if type(c)!=SubBody:
            _dup=c.isDup
        
        if op == '=':
            leftCodeAssign, leftTypeAssign = self.visit(ast.left, Access(frame, sym, True, True))
           
            rightCodeAssign, rightTypeAssign = self.visit(ast.right, Access(frame, sym, False, True, True))
            
            if type(leftTypeAssign) is FloatType and type(rightTypeAssign) is IntType:
                code_I2F = self.emit.emitI2F(frame)
            dup=""
            _code=""
            
            if _dup:
                dup=self.emit.emitDUP(frame)
            if dup:
                self.emit.printout(rightCodeAssign)
                _code=leftCodeAssign+code_I2F
            else:
                _code=leftCodeAssign+rightCodeAssign+code_I2F
            
            self.emit.printout(_code)
            self.emit.printout(dup)
            leftCode_2, leftType_2 = self.visit (ast.left, Access(frame, sym, True, False))
            self.emit.printout(leftCode_2)
            _type=leftType_2
            return _code,_type

        leftCode, leftType = self.visit(ast.left, Access(frame, sym, False, True))
        rightCode, rightType = self.visit(ast.right, Access(frame, sym, False, True))
        
        _code, _type = self.genCodeBinExpr(frame, leftCode, leftType, rightCode, rightType, False)
        if op in ['+','-']:
            _code += self.emit.emitADDOP(op, _type, frame)
        elif op in ['*','/']:
            _code += self.emit.emitMULOP(op, _type, frame)
        elif op == '%':
            _code += self.emit.emitMOD(frame)
        elif op == '&&':
            return self.emit.emitAND_OR_SHORT_CIRCUIT(op, leftCode, rightCode, frame),BoolType()
        elif op == '||':
            return self.emit.emitAND_OR_SHORT_CIRCUIT(op, leftCode, rightCode, frame),BoolType()
        elif op in ["<", "<=", ">", ">=",'!=','==']:
            _code += self.emit.emitREOP(op, _type, frame)
            _type = BoolType()
        return _code, _type
    def visitUnaryOp(self, ast, o):
        #o:any
        #ast.op: string
        #ast.body: Exprs
        
        ctxt = o
        frame = ctxt.frame
        nenv = ctxt.sym

        body, typ = self.visit(ast.body, Access(frame, nenv, False, True))
        if ast.op == '!' and type(typ) is BoolType:
            return body + self.emit.emitNOT(BoolType(), frame), BoolType()
        elif ast.op == '-' and type(typ) is IntType:
            return body + self.emit.emitNEGOP(IntType(), frame), IntType()
        elif ast.op == '-' and type(typ) is FloatType:
            return body + self.emit.emitNEGOP(FloatType(), frame), FloatType()

    def visitId(self, ast, c):
        sym = self.lookup(ast.name, c.sym, lambda x: x.name)
        
        if type(c) != SubBody:
            _code = ""             
            if c.isLeft is True and c.isFirst is True:
                pass
            elif c.isLeft is True and c.isFirst is False:
                if type(sym.mtype) is ArrayType or type(sym.mtype) is ArrayPointerType:
                    _code = self.emit.emitWRITEVAR2(ast.name, sym.mtype, c.frame)
                else:
                    if type(sym.value) is CName:
                        _code = self.emit.emitPUTSTATIC(sym.value.value + "." + ast.name, sym.mtype, c.frame) 
                    elif type(sym.value) is Index:
                        _code = self.emit.emitWRITEVAR(ast.name, sym.mtype, sym.value.value, c.frame)
            elif c.isLeft is False:
                if type(sym.value) is CName:
                    _code = self.emit.emitGETSTATIC(sym.value.value + "." + sym.name, sym.mtype, c.frame) 
                elif type(sym.value) is Index:
                    _code = self.emit.emitREADVAR(ast.name, sym.mtype, sym.value.value, c.frame)
            return _code, sym.mtype
        else:
            return ("", sym.mtype)
    def visitIf(self,ast,c):
        
        frame = c.frame
        sym = c.sym

        _code,_type=self.visit(ast.expr,Access(frame,sym,False,True))
        falseLabel = frame.getNewLabel()
        self.emit.printout(_code+self.emit.emitIFFALSE(falseLabel,frame))
        [self.visit(ast.thenStmt,c)]
        if not ast.elseStmt:
            self.emit.printout(self.emit.emitLABEL(falseLabel,frame))
        else:
            trueLabel=frame.getNewLabel()
            self.emit.printout(self.emit.emitGOTO(trueLabel,frame))
            self.emit.printout(self.emit.emitLABEL(falseLabel,frame))
            [self.visit(ast.elseStmt,c)]
            self.emit.printout(self.emit.emitLABEL(trueLabel,frame))
        return None
    
    def visitDowhile(self,ast,c):
        frame=c.frame
        sym=c.sym
        loopLabel = frame.getNewLabel()
        frame.enterLoop()
        self.emit.printout(self.emit.emitLABEL(loopLabel,frame))
        [self.visit(x,c) for x in ast.sl]
        self.emit.printout(self.emit.emitLABEL(frame.getContinueLabel(),frame))
        _code,_type = self.visit(ast.exp,Access(frame,sym,False,True))
        self.emit.printout(_code)
        self.emit.printout(self.emit.emitIFFALSE(frame.getBreakLabel(),frame))
        self.emit.printout(self.emit.emitGOTO(loopLabel,frame))
        self.emit.printout(self.emit.emitLABEL(frame.getBreakLabel(),frame))
        frame.exitLoop()
        return None
    def visitFor(self,ast,c):
        frame =c.frame
        sym=c.sym
        loopLabel = frame.getNewLabel()
        frame.enterLoop()
        self.visit(ast.expr1,Access(frame,sym,False,True))
        self.emit.printout(self.emit.emitLABEL(loopLabel,frame))
        _code,_type = self.visit(ast.expr2,Access(frame,sym,False,True))
        self.emit.printout(_code)
        self.emit.printout(self.emit.emitIFFALSE(frame.getBreakLabel(),frame))
        if (type(ast.loop) is Block):
            [self.visit(x,c) for x in ast.loop.member]
        else:
            [self.visit(ast.loop,c)]
        self.emit.printout(self.emit.emitLABEL(frame.getContinueLabel(),frame))
        self.visit(ast.expr3,Access(frame,sym,False,True))
        self.emit.printout(self.emit.emitGOTO(loopLabel,frame))
        self.emit.printout(self.emit.emitLABEL(frame.getBreakLabel(),frame))
        frame.exitLoop()
        return None
    def visitReturn(self,ast,c):
        frame=c.frame
        env=c.sym
        if ast.expr:
            _code,_type=self.visit(ast.expr,Access(frame,env,False,True))
            _typeFunc=self.currentFunc.mtype.rettype
            if isinstance(_typeFunc,FloatType) and isinstance(_type,IntType):
                self.emit.printout(_code+self.emit.emitI2F(frame)+self.emit.emitRETURN(FloatType(),frame))
            else:
                self.emit.printout(_code+self.emit.emitRETURN(_type,frame))
        else:
            self.emit.printout(self.emit.emitRETURN(VoidType(),frame))
        return None
    def visitBreak(self,ast,c):
        self.emit.printout(self.emit.emitGOTO(c.frame.getBreakLabel(),c.frame))
        return None
    def visitContinue(self,ast,c):
        self.emit.printout(self.emit.emitGOTO(c.frame.getContinueLabel(),c.frame))
        return None
    def visitCallExpr(self,ast,c):
        lstSym = c.sym
        frame=c.frame
        sym = self.lookup(ast.method.name,lstSym,lambda x: x.name)
        cname = sym.value.value
        ctype = sym.mtype
        lstParaType = ctype.partype

        if type(c) is Access: 
            if c.isLeft and not c.isFirst:
                return self.emit.emitWRITEVAR2(ast.method.name, ctype.rettype, frame), ctype.rettype
        _in = ("",[])
        lstCheck = []
        for item in range(len(lstParaType)):
            lstCheck.append((ast.param[item],lstParaType[item]))
        for x in lstCheck:
            (_code,_type)=self.visit(x[0],Access(frame,lstSym,False,True))
            if type(x[1]) is FloatType and type(_type) is IntType:
                _in=(_in[0]+_code+self.emit.emitI2F(frame),_in[1]+[_type])
            else:
                _in=(_in[0]+_code,_in[1]+[_type])
        
        self.emit.printout(_in[0])
        self.emit.printout(self.emit.emitINVOKESTATIC(cname + "/" + sym.name, ctype, frame))
        return "", ctype.rettype
    def visitArrayCell(self, ast, c):
        frame = c.frame
        sym = c.sym

        if type(c) != SubBody:
            
            if c.isLeft is True and c.isFirst is True:
                (_code, _type) = self.visit(ast.arr, Access(frame, sym, False, True))
                (_codeIdx, _typeIdx) = self.visit(ast.idx, Access(frame, sym, False, True))
                return (_code + _codeIdx, _type.eleType)
            
            elif c.isLeft is True and c.isFirst is False:
                (_code, _type) = self.visit(ast.arr, Access(frame, sym, True, False))
                return (_code, _type)
            
            elif c.isLeft is False:
                (_code, _type) = self.visit(ast.arr, Access(frame, sym, False, True))
                (_codeIdx, _typeIdx) = self.visit(ast.idx, Access(frame, sym, False, True))
                if type(_type) is ArrayType:
                    arrayType = _type.eleType
                    aload = self.emit.emitALOAD(arrayType, frame)
                    return (_code + _codeIdx + aload, arrayType)
                elif type(_type) is ArrayPointerType:
                    arrayPointerType = _type.eleType
                    aload = self.emit.emitALOAD(arrayPointerType, frame)
                    return (_code + _codeIdx + aload, arrayPointerType)
        else:            
            (_code, _type) = self.visit(ast.arr, Access(frame, sym, False, True))
            arrType = _type.eleType
            return ("", arrayType)
        return None
    def visitIntLiteral(self, ast, o):  
        #ast: IntLiteral
        #o: Any
        ctxt = o
        frame = ctxt.frame
        return (self.emit.emitPUSHICONST(ast.value, frame), IntType())
    def visitFloatLiteral(self, ast, o):
        #ast: FloatLiteral
        #o: Any
        ctxt = o
        frame = ctxt.frame
        return self.emit.emitPUSHFCONST(str(ast.value), frame), FloatType()
    def visitBooleanLiteral(self,ast,o):
        ctxt=o
        frame=ctxt.frame
        return self.emit.emitPUSHICONST(str(ast.value),frame),BoolType()
    def visitStringLiteral(self, ast, c):
        ctxt = c
        frame = ctxt.frame
        return self.emit.emitPUSHCONST(ast.value, StringType(), frame), StringType()




    
